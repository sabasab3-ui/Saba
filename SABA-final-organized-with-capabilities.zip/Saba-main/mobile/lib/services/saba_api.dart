import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/saba_models.dart';

class SabaApi {
  SabaApi({String? baseUrl}) : baseUrl = baseUrl ?? 'http://127.0.0.1:8080';

  final String baseUrl;

  Uri _uri(String path) => Uri.parse('$baseUrl$path');

  Future<SabaHealth> health() async {
    final response = await http.get(_uri('/health'));
    _check(response);
    return SabaHealth.fromJson(jsonDecode(response.body));
  }

  Future<SabaAnalysis> analyze(String question) async {
    final response = await http
        .post(
          _uri('/analyze'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'question': question}),
        )
        .timeout(const Duration(seconds: 70));
    _check(response);
    return SabaAnalysis.fromJson(jsonDecode(response.body));
  }

  void _check(http.Response response) {
    if (response.statusCode < 200 || response.statusCode >= 300) {
      try {
        final body = jsonDecode(response.body);
        throw Exception(body['error']?.toString() ?? 'SABA request failed');
      } catch (_) {
        throw Exception('SABA request failed (${response.statusCode})');
      }
    }
  }
}
