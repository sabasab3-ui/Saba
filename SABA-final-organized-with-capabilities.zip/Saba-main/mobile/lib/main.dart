import 'package:flutter/material.dart';
import 'models/saba_models.dart';
import 'services/saba_api.dart';

void main() {
  runApp(const SabaApp());
}

class SabaApp extends StatelessWidget {
  const SabaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SABA AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2563EB),
        brightness: Brightness.dark,
      ),
      home: const SabaHomePage(),
    );
  }
}

class SabaHomePage extends StatefulWidget {
  const SabaHomePage({super.key});

  @override
  State<SabaHomePage> createState() => _SabaHomePageState();
}

class _SabaHomePageState extends State<SabaHomePage> {
  final _questionController = TextEditingController();
  final _api = SabaApi();
  final List<_ChatItem> _messages = [];
  bool _busy = false;
  bool _online = false;

  @override
  void initState() {
    super.initState();
    _checkHealth();
  }

  @override
  void dispose() {
    _questionController.dispose();
    super.dispose();
  }

  Future<void> _checkHealth() async {
    try {
      await _api.health();
      if (mounted) setState(() => _online = true);
    } catch (_) {
      if (mounted) setState(() => _online = false);
    }
  }

  Future<void> _ask() async {
    final question = _questionController.text.trim();
    if (question.isEmpty || _busy) return;

    setState(() {
      _messages.add(_ChatItem.user(question));
      _questionController.clear();
      _busy = true;
    });

    try {
      final result = await _api.analyze(question);
      final answer = _formatAnalysis(result);
      if (mounted) {
        setState(() {
          _messages.add(_ChatItem.saba(answer));
          _online = true;
        });
      }
    } catch (error) {
      if (mounted) {
        setState(() {
          _online = false;
          _messages.add(_ChatItem.saba(
            'I could not reach the SABA intelligence service.\n\n$error',
          ));
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _formatAnalysis(SabaAnalysis result) {
    final buffer = StringBuffer();
    if (result.summary.isNotEmpty) buffer.writeln(result.summary);
    if (result.findings.isNotEmpty) {
      buffer.writeln('\nKey findings:');
      for (final finding in result.findings.take(5)) {
        buffer.writeln('• $finding');
      }
    }
    if (result.decision.isNotEmpty) {
      buffer.writeln('\nDecision: ${result.decision}');
    }
    buffer.writeln(
      '\nConfidence: ${(result.confidence * 100).round()}% · Sources: ${result.sourceCount}',
    );
    return buffer.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 20,
        title: Row(
          children: [
            const CircleAvatar(
              radius: 18,
              child: Icon(Icons.auto_awesome, size: 20),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SABA AI', style: TextStyle(fontWeight: FontWeight.w700)),
                  Text('Smart Automation for Business in Africa', style: TextStyle(fontSize: 11)),
                ],
              ),
            ),
            _StatusDot(online: _online),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: _messages.isEmpty ? const _Welcome() : _Chat(messages: _messages),
            ),
            _Composer(
              controller: _questionController,
              busy: _busy,
              onSend: _ask,
            ),
          ],
        ),
      ),
    );
  }
}

class _Welcome extends StatelessWidget {
  const _Welcome();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: [
            const CircleAvatar(radius: 38, child: Icon(Icons.auto_awesome, size: 38)),
            const SizedBox(height: 20),
            Text('Welcome to SABA', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 10),
            Text(
              'Ask a question and SABA will research and analyze it using the intelligence service.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 24),
            const Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: [
                _Suggestion('Analyze a business idea'),
                _Suggestion('Research a technology'),
                _Suggestion('Compare two options'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Suggestion extends StatelessWidget {
  const _Suggestion(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Chip(
        avatar: const Icon(Icons.lightbulb_outline, size: 16),
        label: Text(text),
      );
}

class _Chat extends StatelessWidget {
  const _Chat({required this.messages});
  final List<_ChatItem> messages;

  @override
  Widget build(BuildContext context) => ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
        itemCount: messages.length,
        itemBuilder: (_, index) {
          final item = messages[index];
          return Align(
            alignment: item.isUser ? Alignment.centerRight : Alignment.centerLeft,
            child: Container(
              constraints: const BoxConstraints(maxWidth: 720),
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: item.isUser
                    ? Theme.of(context).colorScheme.primaryContainer
                    : Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Text(item.text),
            ),
          );
        },
      );
}

class _Composer extends StatelessWidget {
  const _Composer({required this.controller, required this.busy, required this.onSend});
  final TextEditingController controller;
  final bool busy;
  final VoidCallback onSend;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: TextField(
                controller: controller,
                minLines: 1,
                maxLines: 5,
                textInputAction: TextInputAction.newline,
                decoration: InputDecoration(
                  hintText: 'Ask SABA anything…',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                ),
                onSubmitted: (_) => onSend(),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(
              onPressed: busy ? null : onSend,
              icon: busy
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.arrow_upward),
              tooltip: 'Send',
            ),
          ],
        ),
      );
}

class _StatusDot extends StatelessWidget {
  const _StatusDot({required this.online});
  final bool online;

  @override
  Widget build(BuildContext context) => Tooltip(
        message: online ? 'SABA online' : 'SABA offline',
        child: Icon(Icons.circle, size: 11, color: online ? Colors.greenAccent : Colors.grey),
      );
}

class _ChatItem {
  const _ChatItem(this.text, this.isUser);
  final String text;
  final bool isUser;

  factory _ChatItem.user(String text) => _ChatItem(text, true);
  factory _ChatItem.saba(String text) => _ChatItem(text, false);
}
