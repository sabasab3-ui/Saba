class SabaHealth {
  final String status;
  final String service;

  const SabaHealth({required this.status, required this.service});

  factory SabaHealth.fromJson(Map<String, dynamic> json) => SabaHealth(
        status: json['status']?.toString() ?? 'unknown',
        service: json['service']?.toString() ?? 'SABA',
      );
}

class SabaAnalysis {
  final String summary;
  final List<String> findings;
  final String decision;
  final double confidence;
  final int sourceCount;

  const SabaAnalysis({
    required this.summary,
    required this.findings,
    required this.decision,
    required this.confidence,
    required this.sourceCount,
  });

  factory SabaAnalysis.fromJson(Map<String, dynamic> json) => SabaAnalysis(
        summary: json['summary']?.toString() ?? '',
        findings: (json['findings'] as List? ?? const [])
            .map((item) => item.toString())
            .toList(),
        decision: json['decision']?.toString() ?? '',
        confidence: (json['confidence'] as num?)?.toDouble() ?? 0,
        sourceCount: (json['source_count'] as num?)?.toInt() ?? 0,
      );
}
