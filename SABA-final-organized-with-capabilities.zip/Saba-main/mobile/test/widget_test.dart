import 'package:flutter_test/flutter_test.dart';
import 'package:saba_mobile/main.dart';

void main() {
  testWidgets('SABA home renders', (tester) async {
    await tester.pumpWidget(const SabaApp());
    expect(find.text('SABA AI'), findsOneWidget);
    expect(find.text('Welcome to SABA'), findsOneWidget);
  });
}
