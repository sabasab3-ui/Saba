# SABA Mobile

Flutter UI for the SABA Intelligence service.

## Backend connection

Default API: `http://127.0.0.1:8080`

For a physical Android phone, this works when the SABA Go service is running on the same phone. For a remote VPS, build with a configured API URL instead of localhost.

Example:

```bash
flutter pub get
flutter run
```

## Current UI

- SABA-branded Material 3 interface
- Backend health indicator
- Chat-style question/answer flow
- `/analyze` integration
- Findings, decision, confidence and source count display
- Loading and connection-error states
