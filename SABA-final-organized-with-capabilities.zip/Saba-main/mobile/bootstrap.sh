#!/usr/bin/env bash
set -euo pipefail

# Generates Flutter's platform folders while keeping the SABA Dart code.
# Run this once from the mobile directory after installing Flutter.
flutter create --platforms=android,ios,web .
flutter pub get
