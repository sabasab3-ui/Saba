# SABA Specialist Capabilities

SABA now has a lightweight capability layer that sits beside the core modes.

## Core modes
Assistant, Teacher, Coach, Project Manager.

## Specialist capabilities
- Travel Explorer: destination discovery and trip planning.
- Business Builder: customer problems, ideas, tests and plans.
- Education Companion: learning at the user's level.
- Money Planner: budgeting and financial organization.
- Agriculture Assistant: crop and livestock planning support.
- Health Navigation: general information and care navigation, not diagnosis.
- Stuck Solver: reduce a confusing situation to the smallest useful next step.

## Routing concept
User message -> Mode Detector -> Capability Detector -> relevant guidance/tools -> clear next step.

Future versions can replace keyword routing with model-based classification, user preferences, memory and explicit user mode selection.
