# SABA Architecture

SABA is organized into four layers:

1. **Mobile UI** — `mobile/` (Flutter)
2. **Go core** — `cmd/saba/` and `internal/`
3. **Intelligence** — research + analysis pipeline in `internal/intelligence/`
4. **Private agent service** — `openai_agents/`

## Main flow

Flutter → Go `/analyze` → Researcher → Analyzer → structured response → Flutter

## Business tools

The Go tool registry currently exposes inventory, orders and payments. More tools can be added without changing the intelligence engine.

## Security baseline

- Go binds to `127.0.0.1` by default.
- JSON request bodies are size-limited.
- Scraper rejects private/local destinations and unsafe redirects.
- OpenAI Agents `/run` is intended to stay on a private network.
- Secrets belong in environment variables, never source control.
