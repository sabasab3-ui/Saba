# SABA Unified Tool Package

The Go core exposes a discoverable business-tool registry through `GET /tools`.

## Current tools

- `inventory` — manage and query inventory levels
- `orders` — create, list, and update orders
- `payments` — payment-provider boundary for MTN Mobile Money and Airtel Money

## Architecture

```text
SABA Mobile / Dashboard
        |
        v
    Go HTTP API
        |
   +----+----------------+
   |                     |
/analyze               /tools
   |                     |
Research -> Analysis   ToolKit
                         |
              Inventory / Orders / Payments
```

The intelligence engine is deliberately independent from individual business integrations, making it possible to add future tools such as web research, memory, finance data, notifications, scheduling, Telegram/WhatsApp, server monitoring and analytics.

## Development

Run from the repository root:

```bash
go test ./...
go run ./cmd/saba
```

The service exposes:

```text
GET  /health
GET  /tools
POST /analyze
POST /agent
```
