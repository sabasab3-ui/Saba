package main

import (
	"encoding/json"
	"errors"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/sabasab3-ui/saba/internal/agent"
	"github.com/sabasab3-ui/saba/internal/gateway"
	"github.com/sabasab3-ui/saba/internal/intelligence"
)

type analyzeRequest struct {
	Question string                `json:"question"`
	Sources  []intelligence.Source `json:"sources,omitempty"`
}

type analyzeResponse struct {
	Question    string                `json:"question"`
	Summary     string                `json:"summary"`
	Findings    []string              `json:"findings"`
	Decision    string                `json:"decision"`
	Confidence  float64               `json:"confidence"`
	SourceCount int                   `json:"source_count"`
	Sources     []intelligence.Source `json:"sources,omitempty"`
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func withJSON(w http.ResponseWriter, r *http.Request) bool {
	if r.Header.Get("Content-Type") != "application/json" {
		writeJSON(w, http.StatusUnsupportedMediaType, map[string]string{"error": "application/json required"})
		return false
	}
	return true
}

func main() {
	analyzer := intelligence.SmartAnalyzer{}
	researcher := intelligence.NewWebResearcher()
	engine := intelligence.NewEngine(researcher, analyzer)
	toolkit := agent.NewDefaultToolKit()
	gatewayHandler := gateway.New()

	mux := http.NewServeMux()

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{
			"service":   "SABA Intelligence",
			"status":    "ok",
			"message":   "SABA is online.",
			"endpoints": []string{"/health", "/tools", "/analyze", "/agent"},
		})
	})

	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
			return
		}
		writeJSON(w, http.StatusOK, map[string]string{"status": "ok", "service": "SABA Intelligence"})
	})

	mux.HandleFunc("/tools", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{"count": len(toolkit.Catalog()), "tools": toolkit.Catalog()})
	})

	mux.HandleFunc("/analyze", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost || !withJSON(w, r) {
			if r.Method != http.MethodPost {
				writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
			}
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
		defer r.Body.Close()

		var req analyzeRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid JSON"})
			return
		}
		req.Question = strings.TrimSpace(req.Question)
		if req.Question == "" {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "question is required"})
			return
		}

		var findings []string
		var decision string
		var confidence float64
		var sources []intelligence.Source
		var summary string
		var err error

		if len(req.Sources) > 0 {
			sources = req.Sources
			findings, decision, confidence, err = analyzer.Analyze(r.Context(), req.Question, sources)
			summary = "SABA analyzed the supplied evidence."
		} else {
			report, runErr := engine.Run(r.Context(), req.Question)
			if runErr == nil {
				findings, decision, confidence, sources, summary = report.Findings, report.Decision, report.Confidence, report.Sources, report.Summary
			}
			err = runErr
		}
		if err != nil {
			writeJSON(w, http.StatusBadGateway, map[string]string{"error": "intelligence research failed"})
			return
		}

		writeJSON(w, http.StatusOK, analyzeResponse{
			Question: req.Question, Summary: summary, Findings: findings, Decision: decision,
			Confidence: confidence, SourceCount: len(sources), Sources: sources,
		})
	})

	mux.HandleFunc("/agent", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost || !withJSON(w, r) {
			if r.Method != http.MethodPost {
				writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
			}
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
		defer r.Body.Close()
		var req gateway.AgentRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid JSON"})
			return
		}
		if strings.TrimSpace(req.Input) == "" {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "input is required"})
			return
		}
		writeJSON(w, http.StatusOK, gatewayHandler.Route(req))
	})

	// Serve the lightweight browser dashboard shipped with the repository.
	webRoot, err := fs.Sub(webFiles, "web")
	if err != nil {
		log.Fatal(err)
	}
	mux.Handle("/dashboard/", http.StripPrefix("/dashboard/", http.FileServer(http.FS(webRoot))))

	host := os.Getenv("HOST")
	if host == "" {
		host = "127.0.0.1"
	}
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	server := &http.Server{
		Addr:              host + ":" + port,
		Handler:           requestLogging(mux),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       20 * time.Second,
		WriteTimeout:      60 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	log.Printf("SABA Intelligence running on http://%s", server.Addr)
	if err := server.ListenAndServe(); !errors.Is(err, http.ErrServerClosed) {
		log.Fatal(err)
	}
}

func requestLogging(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		next.ServeHTTP(w, r)
		log.Printf("%s %s %s", r.Method, r.URL.Path, time.Since(start).Round(time.Millisecond))
	})
}
