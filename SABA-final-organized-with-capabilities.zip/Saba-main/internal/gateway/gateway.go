package gateway

import (
	"context"
	"fmt"

	"github.com/sabasab3-ui/saba/internal/intelligence"
	"github.com/sabasab3-ui/saba/internal/modes"
)

type AgentRequest struct { Agent string `json:"agent"`; Task string `json:"task"`; Input string `json:"input"` }
type AgentResponse struct {
	Agent string `json:"agent"`; Status string `json:"status"`; Output string `json:"output"`
	Mode string `json:"mode,omitempty"`; ModeGuidance string `json:"mode_guidance,omitempty"`
	Findings []string `json:"findings,omitempty"`; Decision string `json:"decision,omitempty"`; Confidence float64 `json:"confidence,omitempty"`
}

type Gateway struct{}
func New() *Gateway { return &Gateway{} }

func (g *Gateway) Route(req AgentRequest) AgentResponse {
	mode := modes.Detect(req.Input)
	analyzer := intelligence.SmartAnalyzer{}
	findings, decision, confidence, err := analyzer.Analyze(context.Background(), req.Input, nil)
	if err != nil { return AgentResponse{Agent:req.Agent, Status:"error", Output:err.Error(), Mode:string(mode.Mode), ModeGuidance:modes.Guidance(mode.Mode)} }
	return AgentResponse{Agent:req.Agent, Status:"analyzed", Output:fmt.Sprintf("SABA selected %s mode for this request.", mode.Mode), Mode:string(mode.Mode), ModeGuidance:modes.Guidance(mode.Mode), Findings:findings, Decision:decision, Confidence:confidence}
}
