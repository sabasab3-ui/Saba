package agent

import (
	"context"
	"fmt"
	"html"
	"io"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

type WebScraperTool struct{}

func (t *WebScraperTool) Name() string { return "scraper" }
func (t *WebScraperTool) Description() string {
	return "Fetch and extract readable text from a public webpage"
}

func (t *WebScraperTool) Execute(ctx context.Context, params map[string]interface{}) error {
	rawURL, ok := params["url"].(string)
	if !ok || strings.TrimSpace(rawURL) == "" {
		return fmt.Errorf("missing url parameter")
	}

	target, err := url.Parse(strings.TrimSpace(rawURL))
	if err != nil || (target.Scheme != "http" && target.Scheme != "https") || target.Hostname() == "" {
		return fmt.Errorf("url must be a valid http:// or https:// URL")
	}
	if isPrivateHost(target.Hostname()) {
		return fmt.Errorf("private or local network URLs are not allowed")
	}

	client := &http.Client{
		Timeout: 20 * time.Second,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			if len(via) >= 5 {
				return fmt.Errorf("too many redirects")
			}
			if isPrivateHost(req.URL.Hostname()) {
				return fmt.Errorf("redirect to private or local network is not allowed")
			}
			return nil
		},
		Transport: &http.Transport{
			Proxy:           http.ProxyFromEnvironment,
			DialContext:     (&net.Dialer{Timeout: 10 * time.Second, KeepAlive: 30 * time.Second}).DialContext,
			MaxIdleConns:    10,
			IdleConnTimeout: 30 * time.Second,
		},
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, target.String(), nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "SABA-Agent/1.0")
	req.Header.Set("Accept", "text/html,text/plain;q=0.9,*/*;q=0.1")

	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("website returned HTTP %d", resp.StatusCode)
	}

	body, err := io.ReadAll(io.LimitReader(resp.Body, 2*1024*1024))
	if err != nil {
		return err
	}

	text := string(body)
	reScript := regexp.MustCompile(`(?is)<script[^>]*>.*?</script>|<style[^>]*>.*?</style>`)
	text = reScript.ReplaceAllString(text, "")
	reTags := regexp.MustCompile(`(?s)<[^>]*>`)
	text = reTags.ReplaceAllString(text, " ")
	text = html.UnescapeString(text)
	text = strings.Join(strings.Fields(text), " ")
	if len(text) > 10000 {
		text = text[:10000]
	}
	if text == "" {
		return fmt.Errorf("no readable text found")
	}
	return nil
}

func isPrivateHost(host string) bool {
	host = strings.TrimSpace(strings.ToLower(host))
	if host == "localhost" || strings.HasSuffix(host, ".localhost") || host == "::1" {
		return true
	}
	ip := net.ParseIP(host)
	if ip == nil {
		return false
	}
	if ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() {
		return true
	}
	if ip.To4() != nil && ip.To4()[0] == 0 {
		return true
	}
	return false
}
