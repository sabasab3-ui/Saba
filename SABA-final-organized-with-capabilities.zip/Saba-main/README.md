# SABA

SABA (Smart Automation for Business in Africa) is a modular intelligence and automation platform.

## Repository structure

```text
Saba-main/
├── cmd/saba/             # Go service entrypoint and HTTP API
├── internal/
│   ├── agent/             # Tool registry and business tools
│   ├── database/          # SQLite-backed business data helpers
│   ├── gateway/           # Agent routing boundary
│   └── intelligence/      # Research, analysis and reasoning pipeline
├── mobile/                # Flutter Android/iOS UI
├── web/                   # Lightweight browser dashboard
├── openai_agents/         # Optional private OpenAI Agents service
└── docs/                  # Architecture and integration documentation
```

## Go API

- `GET /health` — service health
- `GET /tools` — registered tools
- `POST /analyze` — research and analyze a question
- `POST /agent` — agent gateway boundary
- `/dashboard/` — lightweight browser dashboard when `WEB_DIR` exists

Default address: `http://127.0.0.1:8080`

```bash
go test ./...
go run ./cmd/saba
```

## Mobile UI

The Flutter application lives in `mobile/`.

```bash
cd mobile
flutter pub get
flutter run
```

It connects to `http://127.0.0.1:8080` by default and uses the Go `/analyze` endpoint.

## OpenAI Agents service

The optional Python service in `openai_agents/` provides specialist agents for research, analysis, reasoning, business and coding coordination. Keep it private and configure `OPENAI_API_KEY` through the environment.

See `docs/ARCHITECTURE.md` and `openai_agents/integration/SABA_INTEGRATION.md` for the integration boundary.

## SABA Modes
SABA selects one of four help modes before responding: Assistant, Teacher, Coach, or Project Manager. The selected mode provides response guidance so SABA can adapt its style to the user's immediate need.
