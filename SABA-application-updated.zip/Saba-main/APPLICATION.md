# SABA AI Application

SABA is packaged as a complete application with three client options:

1. **Installable Web App (PWA)** — open `/dashboard/` in a modern browser and use **Install app**.
2. **Flutter mobile client** — under `mobile/`, ready for Android/iOS builds.
3. **Go application server** — the intelligence, tools, API and embedded dashboard.

## Quick start

```bash
./RUN-SABA.sh
```

Then open `http://127.0.0.1:8080/dashboard/`.

For a phone on the same network, run with a LAN bind, for example:

```bash
HOST=0.0.0.0 PORT=8080 ./RUN-SABA.sh
```

Then set the Flutter API endpoint with:

```bash
flutter run --dart-define=SABA_API_URL=http://YOUR-COMPUTER-IP:8080
```

## Production Android APK

The Flutter project is the native mobile application source. Build it with the Android SDK and Flutter installed:

```bash
cd mobile
flutter pub get
flutter build apk --release
```

The current build environment did not contain the Flutter/Android SDK, so an APK could not be compiled here. The project itself is prepared for that build.
