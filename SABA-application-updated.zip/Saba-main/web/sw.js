const CACHE = 'saba-ai-v1';
const APP_SHELL = [
  '/dashboard/',
  '/dashboard/manifest.json',
  '/dashboard/sw.js',
  '/dashboard/assets/branding/saba-icon.png',
  '/dashboard/assets/branding/saba-website-logo.png'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.pathname === '/health' || url.pathname === '/tools') return;
  event.respondWith(fetch(event.request).catch(() => caches.match(event.request)));
});
