package web

import "embed"

// FS contains the production browser dashboard and its static assets.
// Keeping the UI embedded makes the Go service self-contained when built.
//
//go:embed index.html assets
var FS embed.FS
