# SABA Architecture

SABA is split into independently testable layers:

1. **Clients** — Flutter mobile app and embedded browser dashboard.
2. **Go API** — HTTP boundary, validation, routing and service lifecycle.
3. **Business tools** — inventory, orders, payment-provider boundary and web scraping.
4. **Intelligence** — research, evidence analysis and reasoning.
5. **Optional AI orchestration** — private Python/OpenAI Agents service.

## Main research flow

```text
Client
  |
  v
POST /analyze
  |
  v
Intelligence Engine
  |
  +--> Web Research (DuckDuckGo + Google News)
  |
  +--> Evidence Analysis
  |
  +--> Reasoning / confidence
  |
  v
Structured JSON report
```

## Business-tool flow

```text
Client / future agent
        |
        v
     ToolKit
   /    |     \
Inventory Orders Payments
   |
 SQLite
```

The tool interface is intentionally small so new integrations can be added without coupling them to the intelligence engine.

## Web dashboard

`web/` is a Go-embedded static application. The dashboard is served from `/dashboard/`, so the production binary does not depend on the current working directory for its UI assets.

## Optional OpenAI Agents boundary

The Python service is a separate process. Its coding coordinator produces implementation plans only; repository execution belongs to the separate coding/execution layer. Keep the service private and add authentication before exposing it outside a trusted network.

## Security baseline

- Localhost binding by default.
- Bounded JSON request bodies.
- Explicit HTTP method and content-type checks.
- Scraper SSRF protections for private/local IP ranges and redirects.
- Environment-based secrets.
- No claim of successful live payment processing until a real provider integration is installed.
