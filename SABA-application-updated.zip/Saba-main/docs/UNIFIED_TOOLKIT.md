# SABA Unified Tool Package

The Go core exposes a discoverable business-tool registry through `GET /tools`.

## Current tools

- `inventory` — create/update and query inventory records.
- `orders` — create, list and update order status.
- `payments` — validate a supported provider request (MTN Mobile Money or Airtel Money); live settlement is not implemented yet.
- `scraper` — safely fetch readable text from public HTTP(S) pages when explicitly invoked.

## Extension model

Every tool implements:

```go
type Tool interface {
    Name() string
    Description() string
    Execute(context.Context, map[string]interface{}) error
}
```

Register a new implementation with `ToolKit.Register`. The registry keeps catalog output deterministic for clients.

## Development

```bash
go test ./...
go run ./cmd/saba
```
