package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io/fs"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/sabasab3-ui/saba/internal/agent"
	"github.com/sabasab3-ui/saba/internal/database"
	"github.com/sabasab3-ui/saba/internal/gateway"
	"github.com/sabasab3-ui/saba/internal/intelligence"
	"github.com/sabasab3-ui/saba/internal/webhooks"
	staticweb "github.com/sabasab3-ui/saba/web"
)

type analyzeRequest struct {
	Question string                `json:"question"`
	Sources  []intelligence.Source `json:"sources,omitempty"`
}

type analyzeResponse struct {
	Question    string                `json:"question"`
	Summary     string                `json:"summary"`
	Findings    []string              `json:"findings"`
	Decision    string                `json:"decision"`
	Confidence  float64               `json:"confidence"`
	SourceCount int                   `json:"source_count"`
	Sources     []intelligence.Source `json:"sources,omitempty"`
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func withJSON(w http.ResponseWriter, r *http.Request) bool {
	if r.Header.Get("Content-Type") != "application/json" {
		writeJSON(w, http.StatusUnsupportedMediaType, map[string]string{"error": "application/json required"})
		return false
	}
	return true
}

// requireAPIKey protects everything except /health, /dashboard (static
// assets), and the two provider webhook endpoints (which authenticate
// via their own shared-secret query param instead — see internal/webhooks).
// If SABA_API_KEY is unset, auth is skipped entirely: convenient for local
// development, but the server logs a loud warning so this is never
// silently left open in a real deployment.
func requireAPIKey(apiKey string, next http.Handler) http.Handler {
	if apiKey == "" {
		log.Printf("WARNING: SABA_API_KEY is not set — API endpoints are unauthenticated. Set SABA_API_KEY before exposing this server publicly.")
		return next
	}

	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch {
		case r.URL.Path == "/health",
			strings.HasPrefix(r.URL.Path, "/dashboard/"),
			strings.HasPrefix(r.URL.Path, "/webhooks/"):
			next.ServeHTTP(w, r)
			return
		}

		got := r.Header.Get("X-API-Key")
		if got == "" {
			if auth := r.Header.Get("Authorization"); strings.HasPrefix(auth, "Bearer ") {
				got = strings.TrimPrefix(auth, "Bearer ")
			}
		}

		if got == "" || !constantTimeEqual(got, apiKey) {
			writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "missing or invalid API key"})
			return
		}

		next.ServeHTTP(w, r)
	})
}

// constantTimeEqual avoids leaking timing information about how much of
// the caller's key matched, which a plain "==" comparison would do.
func constantTimeEqual(a, b string) bool {
	if len(a) != len(b) {
		return false
	}
	var diff byte
	for i := 0; i < len(a); i++ {
		diff |= a[i] ^ b[i]
	}
	return diff == 0
}

func newRequestID() string {
	buf := make([]byte, 8)
	if _, err := rand.Read(buf); err != nil {
		return "unknown"
	}
	return hex.EncodeToString(buf)
}

type statusRecorder struct {
	http.ResponseWriter
	status int
}

func (s *statusRecorder) WriteHeader(code int) {
	s.status = code
	s.ResponseWriter.WriteHeader(code)
}

// requestLogging emits one structured line per request: a request id
// (so a single request's log lines can be grepped together), method,
// path, status code, and latency.
func requestLogging(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		reqID := newRequestID()
		rec := &statusRecorder{ResponseWriter: w, status: http.StatusOK}

		next.ServeHTTP(rec, r)

		log.Printf(
			"request_id=%s method=%s path=%s status=%d duration_ms=%d",
			reqID, r.Method, r.URL.Path, rec.status, time.Since(start).Milliseconds(),
		)
	})
}

func main() {
	analyzer := intelligence.SmartAnalyzer{}
	researcher := intelligence.NewWebResearcher()
	engine := intelligence.NewEngine(researcher, analyzer)
	toolkit := agent.NewDefaultToolKit()
	gatewayHandler := gateway.New()

	mux := http.NewServeMux()

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{
			"service":   "SABA Intelligence",
			"status":    "ok",
			"message":   "SABA is online.",
			"endpoints": []string{"/health", "/tools", "/analyze", "/agent", "/admin/summary", "/admin/revenue", "/webhooks/mtn", "/webhooks/airtel", "/payments/history", "/directory/register", "/directory/search"},
		})
	})

	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
			return
		}
		writeJSON(w, http.StatusOK, map[string]string{"status": "ok", "service": "SABA Intelligence"})
	})

	mux.HandleFunc("/tools", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{"count": len(toolkit.Catalog()), "tools": toolkit.Catalog()})
	})

	mux.HandleFunc("/analyze", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost || !withJSON(w, r) {
			if r.Method != http.MethodPost {
				writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
			}
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
		defer r.Body.Close()

		var req analyzeRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid JSON"})
			return
		}
		req.Question = strings.TrimSpace(req.Question)
		if req.Question == "" {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "question is required"})
			return
		}

		var findings []string
		var decision string
		var confidence float64
		var sources []intelligence.Source
		var summary string
		var err error

		if len(req.Sources) > 0 {
			sources = req.Sources
			findings, decision, confidence, err = analyzer.Analyze(r.Context(), req.Question, sources)
			summary = "SABA analyzed the supplied evidence."
		} else {
			report, runErr := engine.Run(r.Context(), req.Question)
			if runErr == nil {
				findings, decision, confidence, sources, summary = report.Findings, report.Decision, report.Confidence, report.Sources, report.Summary
			}
			err = runErr
		}
		if err != nil {
			writeJSON(w, http.StatusBadGateway, map[string]string{"error": "intelligence research failed"})
			return
		}

		writeJSON(w, http.StatusOK, analyzeResponse{
			Question: req.Question, Summary: summary, Findings: findings, Decision: decision,
			Confidence: confidence, SourceCount: len(sources), Sources: sources,
		})
	})

	mux.HandleFunc("/agent", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost || !withJSON(w, r) {
			if r.Method != http.MethodPost {
				writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
			}
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
		defer r.Body.Close()
		var req gateway.AgentRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid JSON"})
			return
		}
		if strings.TrimSpace(req.Input) == "" && strings.TrimSpace(req.Task) == "" {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "input or task is required"})
			return
		}
		writeJSON(w, http.StatusOK, gatewayHandler.Route(req))
	})

	// Serve the lightweight browser dashboard shipped with the repository.
	webRoot, err := fs.Sub(staticweb.FS, ".")
	if err != nil {
		log.Fatal(err)
	}
	mux.Handle("/dashboard/", http.StripPrefix("/dashboard/", http.FileServer(http.FS(webRoot))))

	// Payment provider webhooks — see internal/webhooks for the important
	// caveat that the exact callback payload shape should be verified
	// against production traffic before this is trusted for real money.
	paymentDB, err := database.OpenPaymentDB("payments.db")
	if err != nil {
		log.Fatalf("open payments database: %v", err)
	}
	defer paymentDB.Close()

	webhookSecret := os.Getenv("WEBHOOK_SECRET")
	if webhookSecret == "" {
		log.Printf("WARNING: WEBHOOK_SECRET is not set — payment webhooks are disabled (all requests to /webhooks/* will be rejected) until it is set.")
	}
	webhookHandler := webhooks.New(paymentDB, webhookSecret)
	mux.HandleFunc("/webhooks/mtn", webhookHandler.MTNCallback)
	mux.HandleFunc("/webhooks/airtel", webhookHandler.AirtelCallback)

	// Admin summary — aggregate counts across orders/payments/inventory so
	// there's a single place to see the business's real-time state without
	// opening the sqlite files by hand. Protected by the same API key as
	// everything else (see requireAPIKey).
	mux.HandleFunc("/admin/summary", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
			return
		}

		summary := map[string]any{}

		if payStats, err := paymentDB.Summary(); err == nil {
			summary["payments_by_status"] = payStats
		}

		if orderDB, err := database.OpenOrderDB("orders.db"); err == nil {
			defer orderDB.Close()
			if orderStats, err := orderDB.Summary(); err == nil {
				summary["orders_by_status"] = orderStats
			}
		}

		if invDB, err := database.OpenInventoryDB("inventory.db"); err == nil {
			defer invDB.Close()
			if count, err := invDB.Count(); err == nil {
				summary["product_count"] = count
			}
		}

		writeJSON(w, http.StatusOK, summary)
	})

	// Revenue dashboard data. NOTE on scope: SABA currently has no
	// subscription/premium-tier system and no payout/withdrawal flow, so
	// "premium_subscribers" and "payout_status" are honestly reported as
	// not-yet-implemented rather than faked with placeholder numbers —
	// see the admin dashboard HTML for how these are surfaced to the user.
	mux.HandleFunc("/admin/revenue", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
			return
		}

		revenue, err := paymentDB.RevenueSummary()
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not compute revenue summary"})
			return
		}

		writeJSON(w, http.StatusOK, map[string]any{
			"today_earnings":      revenue.TodayEarnings,
			"month_earnings":      revenue.MonthEarnings,
			"successful_payments": revenue.SuccessfulPayments,
			"refunded_amount":     revenue.RefundedAmount,
			"refunded_count":      revenue.RefundedCount,
			"available_balance":   revenue.AvailableBalance,
			"premium_subscribers": nil, // not implemented: SABA has no subscription tiers yet
			"payout_status":       nil, // not implemented: no payout/withdrawal flow yet
		})
	})

	// Payment transaction history — a user's own payments, most recent
	// first. Scoped strictly to msisdn so nobody can browse another
	// user's transactions.
	mux.HandleFunc("/payments/history", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
			return
		}
		msisdn := r.URL.Query().Get("msisdn")
		if msisdn == "" {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "msisdn query parameter is required"})
			return
		}
		history, err := paymentDB.ListByMSISDN(msisdn, 50)
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "could not load payment history"})
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{"msisdn": msisdn, "count": len(history), "payments": history})
	})

	// Business directory — the beginning of SABA's network effect between
	// users. See internal/database/directory.go.
	directoryDB, err := database.OpenDirectoryDB("directory.db")
	if err != nil {
		log.Fatalf("open directory database: %v", err)
	}
	defer directoryDB.Close()

	mux.HandleFunc("/directory/register", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost || !withJSON(w, r) {
			if r.Method != http.MethodPost {
				writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "POST required"})
			}
			return
		}
		r.Body = http.MaxBytesReader(w, r.Body, 1<<16)
		defer r.Body.Close()

		var listing database.Listing
		if err := json.NewDecoder(r.Body).Decode(&listing); err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid JSON"})
			return
		}

		saved, err := directoryDB.Register(listing)
		if err != nil {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": err.Error()})
			return
		}
		writeJSON(w, http.StatusCreated, saved)
	})

	mux.HandleFunc("/directory/search", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			writeJSON(w, http.StatusMethodNotAllowed, map[string]string{"error": "GET required"})
			return
		}
		results, err := directoryDB.Search(
			r.URL.Query().Get("category"),
			r.URL.Query().Get("region"),
			r.URL.Query().Get("kind"),
		)
		if err != nil {
			writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "search failed"})
			return
		}
		writeJSON(w, http.StatusOK, map[string]any{"count": len(results), "listings": results})
	})

	host := os.Getenv("HOST")
	if host == "" {
		host = "127.0.0.1"
	}
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	apiKey := os.Getenv("SABA_API_KEY")

	server := &http.Server{
		Addr:              host + ":" + port,
		Handler:           requestLogging(requireAPIKey(apiKey, mux)),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       20 * time.Second,
		WriteTimeout:      60 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	log.Printf("SABA Intelligence running on http://%s", server.Addr)
	if err := server.ListenAndServe(); !errors.Is(err, http.ErrServerClosed) {
		log.Fatal(err)
	}
}
