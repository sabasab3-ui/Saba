# SABA Mobile

Flutter client for the SABA Go intelligence service.

## Run

```bash
flutter pub get
flutter run
```

The client checks `/health` on startup and uses `/analyze` for research questions.

### API endpoint

- Android emulator: `http://10.0.2.2:8080` by default.
- iOS simulator / desktop: `http://127.0.0.1:8080` by default.
- Physical device or remote server: provide `SABA_API_URL`.

```bash
flutter run --dart-define=SABA_API_URL=http://192.168.x.x:8080
```

## Platform folders

The repository keeps the Dart source without generated Android/iOS platform directories. Run `bootstrap.sh` once if you want Flutter to generate those platform folders locally.
