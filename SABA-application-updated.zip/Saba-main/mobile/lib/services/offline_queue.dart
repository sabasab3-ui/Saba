import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'saba_api.dart';
import '../models/saba_models.dart';

/// A single question that couldn't be sent yet.
class QueuedQuestion {
  QueuedQuestion({required this.id, required this.question, required this.queuedAt});

  final String id;
  final String question;
  final DateTime queuedAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'question': question,
        'queuedAt': queuedAt.toIso8601String(),
      };

  factory QueuedQuestion.fromJson(Map<String, dynamic> json) => QueuedQuestion(
        id: json['id'] as String,
        question: json['question'] as String,
        queuedAt: DateTime.parse(json['queuedAt'] as String),
      );
}

/// Persists questions locally when the network/SABA server is unreachable,
/// and automatically retries them once connectivity returns.
///
/// This is the core of SABA's offline-first behavior: a trader with patchy
/// data in Soroti can still type a question, close the app, and get an
/// answer once they walk somewhere with signal — instead of the request
/// just failing and being lost.
class OfflineQueue {
  OfflineQueue({SabaApi? api}) : _api = api ?? SabaApi();

  static const _storageKey = 'saba_offline_queue_v1';
  final SabaApi _api;
  final _connectivity = Connectivity();

  /// Called with (question, answerOrError, succeeded) for each item as it
  /// is flushed, so the UI can append results to the chat as they resolve.
  void Function(QueuedQuestion item, String resultText, bool succeeded)? onResolved;

  Future<List<QueuedQuestion>> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) return [];
    final list = jsonDecode(raw) as List<dynamic>;
    return list.map((e) => QueuedQuestion.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<void> _save(List<QueuedQuestion> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_storageKey, jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  Future<int> pendingCount() async => (await _load()).length;

  /// Adds a question to the durable queue. Call this when a live send
  /// attempt fails due to connectivity (not for other kinds of errors,
  /// like a 400 from a malformed request — those won't succeed on retry
  /// either).
  Future<void> enqueue(String question) async {
    final items = await _load();
    items.add(QueuedQuestion(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      question: question,
      queuedAt: DateTime.now(),
    ));
    await _save(items);
  }

  /// Attempts to send every queued question. Successfully-sent items are
  /// removed from the queue; items that fail again stay queued for the
  /// next attempt. Safe to call repeatedly (e.g. on every connectivity
  /// change) — it's a no-op when the queue is empty.
  Future<void> flush() async {
    final items = await _load();
    if (items.isEmpty) return;

    final remaining = <QueuedQuestion>[];

    for (final item in items) {
      try {
        final SabaAnalysis result = await _api.analyze(item.question);
        onResolved?.call(item, _formatForQueue(result), true);
      } catch (_) {
        // Still unreachable (or failed again) — keep it queued.
        remaining.add(item);
      }
    }

    await _save(remaining);
  }

  String _formatForQueue(SabaAnalysis result) {
    final buffer = StringBuffer();
    if (result.summary.isNotEmpty) buffer.writeln(result.summary);
    if (result.decision.isNotEmpty) buffer.writeln('Decision: ${result.decision}');
    return buffer.toString().trim();
  }

  /// Starts listening for connectivity changes and calls [flush]
  /// automatically whenever the device regains a network path. Returns a
  /// subscription the caller should cancel in dispose().
  Stream<List<ConnectivityResult>> watchConnectivity() {
    return _connectivity.onConnectivityChanged;
  }
}
