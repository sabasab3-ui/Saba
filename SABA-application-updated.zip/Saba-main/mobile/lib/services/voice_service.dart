import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

/// Wraps on-device speech-to-text and text-to-speech so SABA is usable by
/// voice — important for users less comfortable typing, or typing in a
/// second language. Deliberately on-device (no server API keys, no
/// per-request cost) rather than a cloud STT/TTS provider: it works
/// offline once the OS language pack is installed, and costs nothing per
/// use, which matters for a product built around low-data environments.
///
/// Trade-off worth knowing: on-device recognition quality for Luganda/
/// Swahili varies a lot by phone model and installed language packs — it
/// is not as reliable as a cloud STT service tuned for those languages.
/// If voice accuracy turns out to matter more than cost/offline-support,
/// swapping this for a cloud provider is a contained change (this class
/// is the only place that talks to STT/TTS).
class VoiceService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  bool _speechAvailable = false;

  /// Must be called once (e.g. in initState) before listen() will work.
  /// Returns false if the device has no speech recognition available or
  /// the user denies the microphone permission — callers should hide/
  /// disable the mic button in that case rather than show a broken one.
  Future<bool> init() async {
    _speechAvailable = await _speech.initialize(
      onError: (_) {},
      onStatus: (_) {},
    );
    return _speechAvailable;
  }

  bool get isAvailable => _speechAvailable;
  bool get isListening => _speech.isListening;

  /// Starts listening and calls [onResult] with the live transcript as it
  /// improves (call it again on every partial result; the final call has
  /// the best transcript). Set a language code understood by the device's
  /// speech engine, e.g. "en-US", "sw-KE" — there is no dedicated Luganda
  /// locale on most Android speech engines today, so "en-US" is the safest
  /// default for mixed English/Luganda speech.
  Future<void> listen({
    required void Function(String transcript) onResult,
    String localeId = 'en-US',
  }) async {
    if (!_speechAvailable) return;
    await _speech.listen(
      onResult: (result) => onResult(result.recognizedWords),
      localeId: localeId,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 4),
    );
  }

  Future<void> stopListening() async {
    if (_speech.isListening) await _speech.stop();
  }

  /// Speaks [text] aloud. Silently returns if TTS isn't available for the
  /// device's configured voices — SABA remains fully usable via text even
  /// if voice output fails.
  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    try {
      await _tts.setSpeechRate(0.48);
      await _tts.speak(text);
    } catch (_) {
      // Best-effort — text response is already shown in the chat either way.
    }
  }

  Future<void> stopSpeaking() async {
    await _tts.stop();
  }
}
