import 'dart:async';
import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'models/saba_models.dart';
import 'services/saba_api.dart';
import 'services/offline_queue.dart';
import 'services/voice_service.dart';

void main() {
  runApp(const SabaApp());
}

class SabaApp extends StatelessWidget {
  const SabaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SABA AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2563EB),
        brightness: Brightness.dark,
      ),
      home: const SabaHomePage(),
    );
  }
}

class SabaHomePage extends StatefulWidget {
  const SabaHomePage({super.key});

  @override
  State<SabaHomePage> createState() => _SabaHomePageState();
}

class _SabaHomePageState extends State<SabaHomePage> {
  final _questionController = TextEditingController();
  final _questionFocus = FocusNode();
  final _api = SabaApi();
  final _offlineQueue = OfflineQueue();
  final _voice = VoiceService();
  final List<_ChatItem> _messages = [];
  bool _busy = false;
  bool _online = false;
  bool _voiceAvailable = false;
  bool _listening = false;
  int _pendingCount = 0;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;

  @override
  void initState() {
    super.initState();
    _checkHealth();
    _initVoice();
    _refreshPendingCount();

    _offlineQueue.onResolved = (item, resultText, succeeded) {
      if (!mounted) return;
      setState(() {
        _messages.add(_ChatItem.saba(
          succeeded
              ? '(sent while you were offline: "${item.question}")\n\n$resultText'
              : 'Still unable to send: "${item.question}"',
        ));
        _online = succeeded || _online;
      });
      _refreshPendingCount();
    };

    // Auto-flush the offline queue the moment connectivity returns, so a
    // queued question doesn't just sit there until the user reopens SABA.
    _connectivitySub = _offlineQueue.watchConnectivity().listen((results) {
      final hasConnection = results.any((r) => r != ConnectivityResult.none);
      if (hasConnection) {
        _offlineQueue.flush();
        _checkHealth();
      }
    });
  }

  Future<void> _initVoice() async {
    final available = await _voice.init();
    if (mounted) setState(() => _voiceAvailable = available);
  }

  Future<void> _refreshPendingCount() async {
    final count = await _offlineQueue.pendingCount();
    if (mounted) setState(() => _pendingCount = count);
  }

  @override
  void dispose() {
    _questionController.dispose();
    _questionFocus.dispose();
    _connectivitySub?.cancel();
    super.dispose();
  }

  Future<void> _checkHealth() async {
    try {
      await _api.health();
      if (mounted) setState(() => _online = true);
    } catch (_) {
      if (mounted) setState(() => _online = false);
    }
  }

  /// Sends a tapped quick-reply chip as if the user had typed and sent it.
  Future<void> _sendQuickReply(String reply) async {
    _questionController.text = reply;
    await _ask();
  }

  Future<void> _ask() async {
    final question = _questionController.text.trim();
    if (question.isEmpty || _busy) return;

    setState(() {
      _messages.add(_ChatItem.user(question));
      _questionController.clear();
      _busy = true;
    });

    try {
      final result = await _api.analyze(question);
      final answer = _formatAnalysis(result);
      if (mounted) {
        setState(() {
          _messages.add(_ChatItem.saba(answer, quickReplies: result.quickReplies));
          _online = true;
        });
        _voice.speak(answer);
      }
    } catch (_) {
      // Network/server unreachable: queue it instead of losing the
      // question. It will auto-send once connectivity returns.
      await _offlineQueue.enqueue(question);
      await _refreshPendingCount();
      if (mounted) {
        setState(() {
          _online = false;
          _messages.add(_ChatItem.saba(
            'SABA is unreachable right now. Your question has been saved and '
            'will be sent automatically once you\'re back online.',
          ));
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toggleListening() async {
    if (!_voiceAvailable) return;

    if (_listening) {
      await _voice.stopListening();
      setState(() => _listening = false);
      return;
    }

    setState(() => _listening = true);
    await _voice.listen(
      onResult: (transcript) {
        _questionController.text = transcript;
        _questionController.selection = TextSelection.collapsed(offset: transcript.length);
      },
    );
    // speech_to_text stops itself after a pause; reflect that in the UI.
    if (mounted) setState(() => _listening = _voice.isListening);
  }

  void _fillSuggestion(String text) {
    _questionController.text = text;
    _questionController.selection = TextSelection.collapsed(offset: text.length);
    _questionFocus.requestFocus();
  }

  String _formatAnalysis(SabaAnalysis result) {
    final buffer = StringBuffer();
    if (result.summary.isNotEmpty) buffer.writeln(result.summary);
    if (result.findings.isNotEmpty) {
      buffer.writeln('\nKey findings:');
      for (final finding in result.findings.take(5)) {
        buffer.writeln('• $finding');
      }
    }
    if (result.decision.isNotEmpty) {
      buffer.writeln('\nDecision: ${result.decision}');
    }
    buffer.writeln(
      '\nConfidence: ${(result.confidence * 100).round()}% · Sources: ${result.sourceCount}',
    );
    return buffer.toString().trim();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 20,
        title: Row(
          children: [
            const CircleAvatar(
              radius: 18,
              child: Icon(Icons.auto_awesome, size: 20),
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SABA AI', style: TextStyle(fontWeight: FontWeight.w700)),
                  Text('Smart Automation for Business in Africa', style: TextStyle(fontSize: 11)),
                ],
              ),
            ),
            if (_pendingCount > 0)
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: Tooltip(
                  message: '$_pendingCount question(s) queued, will send when online',
                  child: Chip(
                    avatar: const Icon(Icons.cloud_off, size: 14),
                    label: Text('$_pendingCount'),
                    visualDensity: VisualDensity.compact,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                ),
              ),
            _StatusDot(online: _online),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: _messages.isEmpty
                  ? _Welcome(onSuggestion: _fillSuggestion)
                  : _Chat(
                      messages: _messages,
                      onSpeak: _voice.speak,
                      onQuickReply: _sendQuickReply,
                    ),
            ),
            _Composer(
              controller: _questionController,
              focusNode: _questionFocus,
              busy: _busy,
              onSend: _ask,
              voiceAvailable: _voiceAvailable,
              listening: _listening,
              onToggleListening: _toggleListening,
            ),
          ],
        ),
      ),
    );
  }
}

class _Welcome extends StatelessWidget {
  const _Welcome({required this.onSuggestion});
  final ValueChanged<String> onSuggestion;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: [
            const CircleAvatar(radius: 38, child: Icon(Icons.auto_awesome, size: 38)),
            const SizedBox(height: 20),
            Text('Welcome to SABA', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 10),
            Text(
              'Ask a question and SABA will research and analyze it using the intelligence service.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 24),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              alignment: WrapAlignment.center,
              children: [
                _Suggestion('Analyze a business idea', onTap: () => onSuggestion('Analyze this business idea: ')),
                _Suggestion('Research a technology', onTap: () => onSuggestion('Research this technology: ')),
                _Suggestion('Compare two options', onTap: () => onSuggestion('Compare these options: ')),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Suggestion extends StatelessWidget {
  const _Suggestion(this.text, {required this.onTap});
  final String text;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => ActionChip(
        avatar: const Icon(Icons.lightbulb_outline, size: 16),
        label: Text(text),
        onPressed: onTap,
      );
}

class _Chat extends StatelessWidget {
  const _Chat({required this.messages, this.onSpeak, this.onQuickReply});
  final List<_ChatItem> messages;
  final void Function(String text)? onSpeak;
  final void Function(String reply)? onQuickReply;

  @override
  Widget build(BuildContext context) => ListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 20),
        itemCount: messages.length,
        itemBuilder: (_, index) {
          final item = messages[index];
          return Align(
            alignment: item.isUser ? Alignment.centerRight : Alignment.centerLeft,
            child: Column(
              crossAxisAlignment: item.isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                Container(
                  constraints: const BoxConstraints(maxWidth: 720),
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(15),
                  decoration: BoxDecoration(
                    color: item.isUser
                        ? Theme.of(context).colorScheme.primaryContainer
                        : Theme.of(context).colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(item.text),
                      if (!item.isUser && onSpeak != null)
                        Align(
                          alignment: Alignment.centerRight,
                          child: IconButton(
                            icon: const Icon(Icons.volume_up_outlined, size: 18),
                            tooltip: 'Read aloud',
                            visualDensity: VisualDensity.compact,
                            onPressed: () => onSpeak!(item.text),
                          ),
                        ),
                    ],
                  ),
                ),
                // Tappable quick-reply buttons — lets the user answer a
                // clarifying question with one tap instead of typing.
                if (!item.isUser && item.quickReplies.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: item.quickReplies
                          .map((reply) => OutlinedButton(
                                onPressed: onQuickReply == null ? null : () => onQuickReply!(reply),
                                child: Text(reply),
                              ))
                          .toList(),
                    ),
                  ),
              ],
            ),
          );
        },
      );
}

class _Composer extends StatelessWidget {
  const _Composer({
    required this.controller,
    required this.focusNode,
    required this.busy,
    required this.onSend,
    this.voiceAvailable = false,
    this.listening = false,
    this.onToggleListening,
  });
  final TextEditingController controller;
  final FocusNode focusNode;
  final bool busy;
  final VoidCallback onSend;
  final bool voiceAvailable;
  final bool listening;
  final VoidCallback? onToggleListening;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (voiceAvailable)
              IconButton(
                onPressed: busy ? null : onToggleListening,
                icon: Icon(listening ? Icons.mic : Icons.mic_none),
                tooltip: listening ? 'Stop listening' : 'Speak your question',
                color: listening ? Theme.of(context).colorScheme.error : null,
              ),
            Expanded(
              child: TextField(
                controller: controller,
                focusNode: focusNode,
                minLines: 1,
                maxLines: 5,
                textInputAction: TextInputAction.newline,
                decoration: InputDecoration(
                  hintText: 'Ask SABA anything…',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                ),
                onSubmitted: (_) => onSend(),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(
              onPressed: busy ? null : onSend,
              icon: busy
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.arrow_upward),
              tooltip: 'Send',
            ),
          ],
        ),
      );
}

class _StatusDot extends StatelessWidget {
  const _StatusDot({required this.online});
  final bool online;

  @override
  Widget build(BuildContext context) => Tooltip(
        message: online ? 'SABA online' : 'SABA offline',
        child: Icon(Icons.circle, size: 11, color: online ? Colors.greenAccent : Colors.grey),
      );
}

class _ChatItem {
  const _ChatItem(this.text, this.isUser, {this.quickReplies = const []});
  final String text;
  final bool isUser;
  final List<String> quickReplies;

  factory _ChatItem.user(String text) => _ChatItem(text, true);
  factory _ChatItem.saba(String text, {List<String> quickReplies = const []}) =>
      _ChatItem(text, false, quickReplies: quickReplies);
}
