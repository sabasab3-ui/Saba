// Package capabilities describes SABA's specialist help areas.
package capabilities

import "strings"

type Capability string

const (
	General     Capability = "general"
	Travel      Capability = "travel_explorer"
	Business    Capability = "business_builder"
	Education   Capability = "education_companion"
	Money       Capability = "money_planner"
	Agriculture Capability = "agriculture_assistant"
	Health      Capability = "health_navigation"
	Stuck       Capability = "stuck_solver"
)

type Result struct {
	Capability Capability
	Confidence float64
	Reason     string
}

func Detect(message string) Result {
	t := strings.ToLower(strings.TrimSpace(message))
	checks := []struct {
		c      Capability
		keys   []string
		reason string
	}{
		{Stuck, []string{"i'm stuck", "im stuck", "what do i do now", "don't know what to do", "dont know what to do", "not working"}, "user needs the next clear step"},
		{Travel, []string{"tourist", "travel", "trip", "hotel", "destination", "visit", "near me", "nearby"}, "user may need travel or local exploration help"},
		{Business, []string{"business", "customer", "startup", "sell", "market", "profit"}, "user may need business planning help"},
		{Education, []string{"school", "study", "homework", "exam", "learn", "teach", "lesson"}, "user may need learning support"},
		{Money, []string{"budget", "expense", "saving", "income", "money", "salary"}, "user may need financial organization help"},
		{Agriculture, []string{"farm", "farmer", "crop", "harvest", "soil", "livestock"}, "user may need agriculture support"},
		{Health, []string{"doctor", "hospital", "symptom", "medicine", "health"}, "user may need health navigation"},
	}
	for _, x := range checks {
		for _, k := range x.keys {
			if strings.Contains(t, k) {
				return Result{x.c, .82, x.reason}
			}
		}
	}
	return Result{General, .65, "general assistance"}
}

func Guidance(c Capability) string {
	switch c {
	case Travel:
		return "Clarify destination, dates, budget, interests, and location permissions before creating a practical travel plan."
	case Business:
		return "Clarify the customer problem, value proposition, costs, and smallest test before recommending a business plan."
	case Education:
		return "Adapt to the learner's level, explain clearly, give practice, and identify one next learning step."
	case Money:
		return "Help organize income, expenses, goals, and options; avoid pretending to provide regulated financial advice."
	case Agriculture:
		return "Clarify crop or livestock, location, season, and constraints before suggesting practical next steps."
	case Health:
		return "Provide general health information and navigation, not diagnosis; encourage qualified care for urgent or serious concerns."
	case Stuck:
		return "Understand the situation, identify what has already been tried, and give the smallest useful next step."
	default:
		return "Use the appropriate SABA mode and help area, then give a clear next action."
	}
}
