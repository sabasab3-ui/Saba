package capabilities

import "testing"

func TestDetectCapabilities(t *testing.T) {
	cases := []struct {
		input string
		want  Capability
	}{
		{"help me plan a trip", Travel},
		{"how can I improve my business profit", Business},
		{"help me study for an exam", Education},
		{"help me budget my salary", Money},
		{"what crop should I plant", Agriculture},
		{"where is a good hospital", Health},
		{"I'm stuck, what do I do now?", Stuck},
	}
	for _, tc := range cases {
		if got := Detect(tc.input).Capability; got != tc.want {
			t.Errorf("Detect(%q) = %q, want %q", tc.input, got, tc.want)
		}
	}
}
