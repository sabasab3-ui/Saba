// Package webhooks receives asynchronous payment-outcome callbacks from
// MTN MoMo and Airtel Money, so SABA doesn't have to rely solely on
// polling CheckStatus.
//
// IMPORTANT — verify against the provider docs before going live:
// Both providers' exact callback JSON shape and signing/verification
// scheme can differ between sandbox and production, and MTN's sandbox
// does not deliver callbacks at all (per their own developer docs) — you
// can only exercise this code path in production, or by POSTing a fake
// payload yourself while testing. The field names below match the
// commonly-documented shapes as of this writing; inspect the *actual*
// payload your provider sends (log it) and adjust the structs if it
// differs before trusting this in production.
package webhooks

import (
	"encoding/json"
	"io"
	"log"
	"net/http"

	"github.com/sabasab3-ui/saba/internal/database"
	"github.com/sabasab3-ui/saba/internal/payments"
)

const maxWebhookBody = 1 << 20 // 1MB — callbacks are small JSON payloads

// Handler wires provider webhooks to payment persistence.
type Handler struct {
	DB     *database.PaymentDB
	Secret string // shared secret this handler expects on inbound callbacks
}

func New(db *database.PaymentDB, secret string) *Handler {
	return &Handler{DB: db, Secret: secret}
}

// checkSecret enforces a shared-secret query param as a minimal defense
// against random internet traffic hitting the webhook path.
//
// This is NOT a substitute for real provider signature verification.
// MTN and Airtel each document their own callback-authenticity mechanism
// (e.g. an IP allowlist, or a signed header) — implement that too once you
// have production access and can see their real callback traffic. Until
// then, treat any webhook-driven status change as provisional and
// reconcile it against CheckStatus before treating an order as paid for
// anything high-value.
func (h *Handler) checkSecret(r *http.Request) bool {
	if h.Secret == "" {
		// No secret configured: refuse to run wide open in production.
		return false
	}
	return r.URL.Query().Get("secret") == h.Secret
}

// MTNCallback handles MTN MoMo's request-to-pay callback.
// Expected (commonly documented) shape:
//
//	{
//	  "financialTransactionId": "...",
//	  "externalId": "...",
//	  "amount": "...",
//	  "currency": "...",
//	  "status": "SUCCESSFUL" | "FAILED",
//	  "reason": { "code": "...", "message": "..." }
//	}
//
// MTN does not put the X-Reference-Id in the callback body — it's the
// value you generated in RequestToPay, and typically MTN correlates the
// callback to your original request out-of-band (by the URL you
// registered, and/or you match on externalId). We match on externalId
// here since that's the field guaranteed to be yours.
func (h *Handler) MTNCallback(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	if !h.checkSecret(r) {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	body, err := io.ReadAll(io.LimitReader(r.Body, maxWebhookBody))
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	defer r.Body.Close()

	log.Printf("mtn webhook received: %s", string(body))

	var payload struct {
		FinancialTransactionID string `json:"financialTransactionId"`
		ExternalID              string `json:"externalId"`
		Status                  string `json:"status"`
	}
	if err := json.Unmarshal(body, &payload); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	status := normalizeStatus(payload.Status)

	existing, err := h.DB.GetByExternalID("mtn", payload.ExternalID)
	if err != nil {
		log.Printf("mtn webhook: no local payment found for externalId=%s: %v", payload.ExternalID, err)
		// Still 200 — MTN will retry on non-2xx, and retrying won't fix a
		// payment we never created a record for.
		w.WriteHeader(http.StatusOK)
		return
	}

	if _, err := h.DB.UpdateStatusByReference("mtn", existing.ReferenceID, string(status)); err != nil {
		log.Printf("mtn webhook: failed to update payment status: %v", err)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

// AirtelCallback handles Airtel Money's transaction callback.
// Expected (commonly documented) shape:
//
//	{
//	  "transaction": {
//	    "id": "...",
//	    "airtel_money_id": "...",
//	    "status_code": "TS" | "TF",
//	    "message": "..."
//	  }
//	}
func (h *Handler) AirtelCallback(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return
	}
	if !h.checkSecret(r) {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}

	body, err := io.ReadAll(io.LimitReader(r.Body, maxWebhookBody))
	if err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}
	defer r.Body.Close()

	log.Printf("airtel webhook received: %s", string(body))

	var payload struct {
		Transaction struct {
			ID         string `json:"id"`
			StatusCode string `json:"status_code"`
		} `json:"transaction"`
	}
	if err := json.Unmarshal(body, &payload); err != nil {
		w.WriteHeader(http.StatusBadRequest)
		return
	}

	// Airtel's transaction.id is the merchant-supplied reference — for our
	// client that's req.ExternalID, which we also used as the reference on
	// RequestToPay's fallback path. Match on externalId first.
	existing, err := h.DB.GetByExternalID("airtel", payload.Transaction.ID)
	if err != nil {
		log.Printf("airtel webhook: no local payment found for id=%s: %v", payload.Transaction.ID, err)
		w.WriteHeader(http.StatusOK)
		return
	}

	var status payments.Status
	switch payload.Transaction.StatusCode {
	case "TS":
		status = payments.StatusSuccess
	case "TF":
		status = payments.StatusFailed
	default:
		status = payments.StatusPending
	}

	if _, err := h.DB.UpdateStatusByReference("airtel", existing.ReferenceID, string(status)); err != nil {
		log.Printf("airtel webhook: failed to update payment status: %v", err)
		w.WriteHeader(http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
}

func normalizeStatus(raw string) payments.Status {
	switch raw {
	case "SUCCESSFUL":
		return payments.StatusSuccess
	case "FAILED":
		return payments.StatusFailed
	case "PENDING":
		return payments.StatusPending
	default:
		return payments.StatusUnknown
	}
}
