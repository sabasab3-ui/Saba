package intelligence

import (
	"context"
	"errors"
	"testing"
)

type fakeResearcher struct {
	sources []Source
	err     error
}

func (f fakeResearcher) Research(context.Context, string) ([]Source, error) { return f.sources, f.err }

type fakeAnalyzer struct{ err error }

func (f fakeAnalyzer) Analyze(context.Context, string, []Source) ([]string, string, float64, error) {
	return []string{"finding"}, "decision", 1.4, f.err
}

func TestEngineRunClampsConfidence(t *testing.T) {
	e := NewEngine(fakeResearcher{sources: []Source{{Title: "A", Content: "B"}}}, fakeAnalyzer{})
	report, err := e.Run(context.Background(), "question")
	if err != nil {
		t.Fatal(err)
	}
	if report.Confidence != 1 {
		t.Fatalf("expected clamped confidence 1, got %v", report.Confidence)
	}
}

func TestEngineRejectsEmptyQuestion(t *testing.T) {
	_, err := NewEngine(fakeResearcher{}, fakeAnalyzer{}).Run(context.Background(), "  ")
	if !errors.Is(err, ErrEmptyQuestion) {
		t.Fatalf("expected ErrEmptyQuestion, got %v", err)
	}
}

func TestEnginePropagatesResearchError(t *testing.T) {
	want := errors.New("research failed")
	_, err := NewEngine(fakeResearcher{err: want}, fakeAnalyzer{}).Run(context.Background(), "question")
	if !errors.Is(err, want) {
		t.Fatalf("expected research error, got %v", err)
	}
}
