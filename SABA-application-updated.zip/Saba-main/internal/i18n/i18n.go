// Package i18n provides basic multi-language support for SABA's
// mode-guidance text, aimed first at Uganda's most common languages.
//
// This is intentionally a small, hand-maintained phrase table, not a
// translation service — it covers the fixed guidance strings that
// modes.Guidance produces. Free-form model/agent output (the Python
// OpenAI Agents service, or anything generated rather than templated)
// is NOT translated by this package; that would need the underlying
// model to be prompted in the target language instead.
//
// TRANSLATION CONFIDENCE — read before adding a language to production:
// Swahili and Luganda are widely documented languages I have reasonable
// confidence in. Ateso, Acholi, and Runyankole are far less represented
// in training data generally, and I do not have a reliable way to verify
// these translations myself. Treat them as a rough first draft, NOT
// verified correct — have a native speaker of each review before this
// ships to real users. Shipping a wrong or awkward translation to a
// specific language community is worse than staying in English for that
// community, since it signals carelessness about exactly the audience
// SABA is trying to serve well.
package i18n

import "strings"

// Lang is a supported language code.
type Lang string

const (
	English    Lang = "en"
	Luganda    Lang = "lg"
	Swahili    Lang = "sw"
	Ateso      Lang = "teo" // Teso region — includes Soroti
	Acholi     Lang = "ach" // Northern Uganda
	Runyankole Lang = "nyn" // Western Uganda (Ankole)
)

// Detect maps a free-form language field (as sent by a client) to a
// supported Lang, defaulting to English for anything unrecognized so a
// typo or unset field never breaks the response.
func Detect(raw string) Lang {
	switch strings.ToLower(strings.TrimSpace(raw)) {
	case "lg", "luganda", "ganda":
		return Luganda
	case "sw", "swahili", "kiswahili":
		return Swahili
	case "teo", "ateso", "iteso":
		return Ateso
	case "ach", "acholi", "acoli":
		return Acholi
	case "nyn", "runyankole", "nkore", "ankole":
		return Runyankole
	default:
		return English
	}
}

// modeGuidance holds the same four guidance strings from modes.Guidance,
// translated. Keys match modes.Mode values as strings so callers don't
// need to import the modes package just to look something up.
var modeGuidance = map[Lang]map[string]string{
	English: {
		"teacher":         "Explain clearly, step by step, check understanding, and end with one practical next action.",
		"coach":           "Acknowledge the obstacle, reduce the problem to a small achievable step, encourage progress, and avoid overwhelming the user.",
		"project_manager": "Clarify the goal, break it into milestones and small tasks, identify the highest-priority next step, and track progress.",
		"assistant":       "Answer directly, be useful, and propose the clearest next action when one exists.",
	},
	Luganda: {
		"teacher":         "Nnyonnyola bulungi, ekitundu ku kitundu, kebera obutegeevu, era omalirize n'ekikolwa kimu eky'omugaso.",
		"coach":           "Kkiriza ekizibu, kifunze mu kadde akatono akasoboka, gumya omuntu, era wewale okumusukkirira.",
		"project_manager": "Nnyonnyola ekigendererwa, kimenyemu mu bitundu n'emirimu emitono, laga ekisooka mu kya bulijjo, era olondoole enkulaakulana.",
		"assistant":       "Ddamu butereevu, beera wa mugaso, era lambika ekikolwa ekisinga obulungi bwe kiba nga kiriwo.",
	},
	Swahili: {
		"teacher":         "Eleza kwa uwazi, hatua kwa hatua, hakikisha uelewa, na malizia na hatua moja ya vitendo.",
		"coach":           "Tambua kikwazo, punguza tatizo kuwa hatua ndogo inayowezekana, tia moyo maendeleo, na epuka kumlemea mtumiaji.",
		"project_manager": "Fafanua lengo, ligawanye katika hatua na kazi ndogondogo, bainisha hatua muhimu zaidi ifuatayo, na fuatilia maendeleo.",
		"assistant":       "Jibu moja kwa moja, kuwa msaada, na pendekeza hatua iliyo wazi zaidi inapokuwepo.",
	},
	// DRAFT — needs native-speaker review before production use.
	Ateso: {
		"teacher":         "Bwokis apolou, kere ka kere, sitim ebe erupokini, kolimok ka etyakisit acelacel a ilosit.",
		"coach":           "Kirilim ejaasi, kotanan angesikesio ejaasi ekiring, kigira ekiro, kong ipedori ejaasi ejaasi.",
		"project_manager": "Bwokis erai, kotanan ka ebe achok ka irien inyot, sitam erai lu ipol, kolimok epedori.",
		"assistant":       "Kilim ecoreni, iyar ka erai, kolimok etyakisit ejaasi ejaasi noi eboto.",
	},
	// DRAFT — needs native-speaker review before production use.
	Acholi: {
		"teacher":         "Nyut maleng, kong ki kong, nen ka gineno maber, ci gik ki tim acel me kony.",
		"coach":           "Nyut ni gineno peko, doko peko madit obed matidi ma gitwero timo, jiwu tam, pe imed peko.",
		"project_manager": "Ler tam madit, poke i teko madito ki matidi, nyut gin mukwongo me timo, ci lub kaka gitye kwede.",
		"assistant":       "Dwok maber tir, bed ki kony, ci nyut gin ma myero gitim ka tye.",
	},
	// DRAFT — needs native-speaker review before production use.
	Runyankole: {
		"teacher":         "Shoboorora gye, omuli n'omuli, reeba ku bakwatsize, oheereze n'ekintu kimwe eky'okukora.",
		"coach":           "Kiriza oburemeezi, kigabanise omuli mutoya ogurikubaasika, higa, kandi otarikwongyera oburemeezi.",
		"project_manager": "Shoboorora entaro, gyegaba omu bicweka n'emirimo mitoya, oreke ekirikwetengyesa okukora, ogyendereze.",
		"assistant":       "Garukamu directly, ba ow'omugasho, kandi orikweteise ekikorwa kirungi ku kiriho.",
	},
}

// Guidance returns mode guidance text in the requested language, falling
// back to English if the mode or language isn't in the table.
func Guidance(mode string, lang Lang) string {
	if byLang, ok := modeGuidance[lang]; ok {
		if text, ok := byLang[mode]; ok {
			return text
		}
	}
	return modeGuidance[English][mode]
}
