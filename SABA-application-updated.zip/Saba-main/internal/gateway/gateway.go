package gateway

import (
	"fmt"

	"github.com/sabasab3-ui/saba/internal/capabilities"
	"github.com/sabasab3-ui/saba/internal/modes"
)

type AgentRequest struct {
	Agent string `json:"agent,omitempty"`
	Task  string `json:"task,omitempty"`
	Input string `json:"input,omitempty"`
}

type AgentResponse struct {
	Agent              string `json:"agent,omitempty"`
	Status             string `json:"status"`
	Output             string `json:"output"`
	Mode               string `json:"mode"`
	ModeGuidance       string `json:"mode_guidance"`
	Capability         string `json:"capability"`
	CapabilityGuidance string `json:"capability_guidance"`
}

type Gateway struct{}

func New() *Gateway { return &Gateway{} }

// Route classifies a request and returns the guidance that downstream agents
// or clients should use. It deliberately does not execute external actions.
func (g *Gateway) Route(req AgentRequest) AgentResponse {
	input := req.Input
	if input == "" {
		input = req.Task
	}

	mode := modes.Detect(input)
	capability := capabilities.Detect(input)

	return AgentResponse{
		Agent:              req.Agent,
		Status:             "routed",
		Output:             fmt.Sprintf("SABA routed this request to %s mode and %s capability.", mode.Mode, capability.Capability),
		Mode:               string(mode.Mode),
		ModeGuidance:       modes.Guidance(mode.Mode),
		Capability:         string(capability.Capability),
		CapabilityGuidance: capabilities.Guidance(capability.Capability),
	}
}
