package gateway

import "testing"

func TestRouteUsesInput(t *testing.T) {
	response := New().Route(AgentRequest{Agent: "test", Input: "teach me how inventory works"})
	if response.Status != "routed" {
		t.Fatalf("expected routed, got %q", response.Status)
	}
	if response.Mode != "teacher" {
		t.Fatalf("expected teacher mode, got %q", response.Mode)
	}
	if response.Capability != "education_companion" {
		t.Fatalf("expected education capability, got %q", response.Capability)
	}
}

func TestRouteFallsBackToTask(t *testing.T) {
	response := New().Route(AgentRequest{Task: "build a business roadmap"})
	if response.Mode != "project_manager" {
		t.Fatalf("expected project_manager, got %q", response.Mode)
	}
}
