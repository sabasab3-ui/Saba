// Package sms provides an SMS-sending abstraction so SABA can reach users
// without a smartphone or reliable data — a meaningful gap for a Uganda-
// focused product.
//
// STATUS: this is a scaffold, not a wired-in feature. Sending a real SMS
// requires its own developer account (africastalking.com — separate from
// MTN/Airtel), its own API credentials, and — unlike the payment
// providers — a small per-message cost with no free sandbox for real
// delivery. Nothing in cmd/saba calls this package yet. To turn it on:
//
//  1. Register at africastalking.com, get an API key + username.
//  2. Set AFRICASTALKING_USERNAME / AFRICASTALKING_API_KEY in .env.
//  3. Call sms.NewAfricasTalkingProvider + Send(...) from wherever SABA
//     should notify a user (e.g. after a payment status changes).
package sms

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"time"
)

// Provider is implemented by each SMS backend so SABA isn't locked to one
// vendor.
type Provider interface {
	Send(ctx context.Context, to string, message string) error
}

// AfricasTalkingConfig holds the credentials issued by Africa's Talking.
type AfricasTalkingConfig struct {
	Username string
	APIKey   string
	// BaseURL defaults to the live endpoint; Africa's Talking's sandbox
	// (username "sandbox") is used for testing without sending real SMS.
	BaseURL string
	// SenderID / shortcode, if you have a registered one. Optional — if
	// empty, messages send from Africa's Talking's shared/generic sender.
	From string
}

func (c AfricasTalkingConfig) valid() bool {
	return c.Username != "" && c.APIKey != ""
}

type AfricasTalkingProvider struct {
	cfg    AfricasTalkingConfig
	client *http.Client
}

var ErrMissingConfig = fmt.Errorf("sms: provider is not configured (missing credentials)")

// NewAfricasTalkingProvider builds a client. Returns ErrMissingConfig if
// username/API key are absent, matching the payments package's pattern of
// "unconfigured is not a startup error."
func NewAfricasTalkingProvider(cfg AfricasTalkingConfig) (*AfricasTalkingProvider, error) {
	if !cfg.valid() {
		return nil, ErrMissingConfig
	}
	if cfg.BaseURL == "" {
		cfg.BaseURL = "https://api.africastalking.com/version1/messaging"
	}
	return &AfricasTalkingProvider{
		cfg:    cfg,
		client: &http.Client{Timeout: 15 * time.Second},
	}, nil
}

// Send implements Provider by POSTing to Africa's Talking's messaging
// endpoint. `to` should be in international format, e.g. "+256746206115".
func (a *AfricasTalkingProvider) Send(ctx context.Context, to string, message string) error {
	if to == "" || message == "" {
		return fmt.Errorf("sms: recipient and message are required")
	}

	form := url.Values{}
	form.Set("username", a.cfg.Username)
	form.Set("to", to)
	form.Set("message", message)
	if a.cfg.From != "" {
		form.Set("from", a.cfg.From)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, a.cfg.BaseURL, bytes.NewBufferString(form.Encode()))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("apiKey", a.cfg.APIKey)

	resp, err := a.client.Do(req)
	if err != nil {
		return fmt.Errorf("sms: send request failed: %w", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusCreated && resp.StatusCode != http.StatusOK {
		return fmt.Errorf("sms: provider rejected message, status %d: %s", resp.StatusCode, string(body))
	}

	var result struct {
		SMSMessageData struct {
			Recipients []struct {
				Status string `json:"status"`
			} `json:"Recipients"`
		} `json:"SMSMessageData"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		// Delivery likely still succeeded (status code was 2xx); don't fail
		// the whole call over a response-parsing issue.
		return nil
	}
	for _, r := range result.SMSMessageData.Recipients {
		if r.Status != "" && r.Status != "Success" {
			return fmt.Errorf("sms: provider reported non-success recipient status: %s", r.Status)
		}
	}
	return nil
}
