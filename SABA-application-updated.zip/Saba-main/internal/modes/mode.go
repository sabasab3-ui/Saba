package modes

import "strings"

type Mode string

const (
	Assistant      Mode = "assistant"
	Teacher        Mode = "teacher"
	Coach          Mode = "coach"
	ProjectManager Mode = "project_manager"
)

type Result struct {
	Mode       Mode
	Confidence float64
	Reason     string
}

func Detect(message string) Result {
	t := strings.ToLower(strings.TrimSpace(message))
	if t == "" {
		return Result{Assistant, 1, "empty or general request"}
	}
	coach := []string{"stuck", "bored", "motivation", "give up", "focus", "confused", "discouraged", "goal"}
	teacher := []string{"teach", "learn", "explain", "understand", "how does", "lesson", "why does", "show me how"}
	project := []string{"build", "project", "roadmap", "organize", "milestone", "next step", "plan", "launch"}
	for _, k := range coach {
		if strings.Contains(t, k) {
			return Result{Coach, .90, "user may need guidance, focus, or encouragement"}
		}
	}
	for _, k := range teacher {
		if strings.Contains(t, k) {
			return Result{Teacher, .88, "user is learning or asking for explanation"}
		}
	}
	for _, k := range project {
		if strings.Contains(t, k) {
			return Result{ProjectManager, .88, "user is planning, building, or organizing"}
		}
	}
	return Result{Assistant, .70, "general assistance request"}
}

func Guidance(mode Mode) string {
	switch mode {
	case Teacher:
		return "Explain clearly, step by step, check understanding, and end with one practical next action."
	case Coach:
		return "Acknowledge the obstacle, reduce the problem to a small achievable step, encourage progress, and avoid overwhelming the user."
	case ProjectManager:
		return "Clarify the goal, break it into milestones and small tasks, identify the highest-priority next step, and track progress."
	default:
		return "Answer directly, be useful, and propose the clearest next action when one exists."
	}
}
