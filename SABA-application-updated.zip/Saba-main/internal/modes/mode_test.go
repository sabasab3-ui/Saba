package modes

import "testing"

func TestDetectModes(t *testing.T) {
	cases := []struct {
		input string
		want  Mode
	}{
		{"teach me how this works", Teacher},
		{"I am stuck on this", Coach},
		{"build a roadmap for the project", ProjectManager},
		{"hello SABA", Assistant},
	}
	for _, tc := range cases {
		if got := Detect(tc.input).Mode; got != tc.want {
			t.Errorf("Detect(%q) = %q, want %q", tc.input, got, tc.want)
		}
	}
}
