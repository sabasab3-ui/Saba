// Package payments provides real mobile-money integrations (MTN MoMo,
// Airtel Money) behind a single Provider interface. Credentials are read
// from the environment only; nothing is hard-coded and nothing is logged.
package payments

import (
	"context"
	"errors"
	"fmt"
	"time"
)

// Status is the lifecycle state of a mobile-money transaction.
type Status string

const (
	StatusPending   Status = "PENDING"
	StatusSuccess   Status = "SUCCESSFUL"
	StatusFailed    Status = "FAILED"
	StatusUnknown   Status = "UNKNOWN"
)

// PaymentRequest describes a request-to-pay (collection) call.
type PaymentRequest struct {
	// Amount as a decimal string, e.g. "1500.00". Kept as a string end to
	// end so no floating-point rounding ever touches real money.
	Amount string
	// Currency, e.g. "UGX".
	Currency string
	// MSISDN of the payer, digits only, no leading "+", e.g. "256746206115".
	MSISDN string
	// ExternalID is the merchant-side reference for this transaction
	// (SABA order ID, invoice number, etc). Must be unique per request.
	ExternalID string
	// Note shown to the payer / kept for the payee's own records.
	PayerMessage string
	PayeeNote    string
}

// PaymentResult is returned once a provider accepts (or rejects) the
// collection request. For async providers (MTN, Airtel) "accepted" only
// means the request was submitted for approval on the payer's phone —
// call CheckStatus to learn the final outcome.
type PaymentResult struct {
	Provider      string
	ReferenceID   string // provider-side transaction/reference id
	Status        Status
	RawStatusCode int
}

// Provider is implemented by each mobile-money integration.
type Provider interface {
	// Name returns the provider identifier used in tool params ("mtn", "airtel").
	Name() string

	// RequestToPay initiates a collection (push payment prompt to the payer's phone).
	RequestToPay(ctx context.Context, req PaymentRequest) (*PaymentResult, error)

	// CheckStatus polls the provider for the current status of a prior request.
	CheckStatus(ctx context.Context, referenceID string) (*PaymentResult, error)
}

var (
	ErrMissingConfig    = errors.New("payments: provider is not configured (missing credentials)")
	ErrInvalidRequest   = errors.New("payments: invalid payment request")
	ErrProviderRejected = errors.New("payments: provider rejected the request")
)

func validate(req PaymentRequest) error {
	if req.Amount == "" {
		return fmt.Errorf("%w: amount is required", ErrInvalidRequest)
	}
	if req.Currency == "" {
		return fmt.Errorf("%w: currency is required", ErrInvalidRequest)
	}
	if req.MSISDN == "" {
		return fmt.Errorf("%w: payer phone number is required", ErrInvalidRequest)
	}
	if req.ExternalID == "" {
		return fmt.Errorf("%w: externalId is required", ErrInvalidRequest)
	}
	return nil
}

// defaultHTTPTimeout bounds every outbound call to a payment provider so a
// slow/unreachable provider can never hang a request handling goroutine.
const defaultHTTPTimeout = 20 * time.Second
