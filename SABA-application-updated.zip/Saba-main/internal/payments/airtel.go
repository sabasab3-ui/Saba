package payments

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sync"
	"time"

	"github.com/google/uuid"
)

// AirtelConfig holds the credentials issued by the Airtel Money Open API
// developer portal (openapiuat.airtel.africa for UAT / openapi.airtel.africa
// for production).
//
// Required env vars (see .env.example):
//
//	AIRTEL_BASE_URL       e.g. https://openapiuat.airtel.africa (UAT)
//	                            or https://openapi.airtel.africa (production)
//	AIRTEL_CLIENT_ID      OAuth client id
//	AIRTEL_CLIENT_SECRET  OAuth client secret
//	AIRTEL_COUNTRY        two-letter country code, e.g. "UG"
//	AIRTEL_CURRENCY       e.g. "UGX"
type AirtelConfig struct {
	BaseURL      string
	ClientID     string
	ClientSecret string
	Country      string
	Currency     string
}

func (c AirtelConfig) valid() bool {
	return c.BaseURL != "" && c.ClientID != "" && c.ClientSecret != "" &&
		c.Country != "" && c.Currency != ""
}

// AirtelProvider implements Provider against the Airtel Money Collections
// (merchant payment) API.
type AirtelProvider struct {
	cfg    AirtelConfig
	client *http.Client

	mu          sync.Mutex
	accessToken string
	tokenExpiry time.Time
}

// NewAirtelProvider builds an Airtel Money client. Returns ErrMissingConfig
// if any required credential is absent.
func NewAirtelProvider(cfg AirtelConfig) (*AirtelProvider, error) {
	if !cfg.valid() {
		return nil, ErrMissingConfig
	}
	return &AirtelProvider{
		cfg:    cfg,
		client: &http.Client{Timeout: defaultHTTPTimeout},
	}, nil
}

func (a *AirtelProvider) Name() string { return "airtel" }

// authenticate obtains (and caches) an OAuth2 client-credentials token via
// POST /auth/oauth2/token.
func (a *AirtelProvider) authenticate(ctx context.Context) (string, error) {
	a.mu.Lock()
	defer a.mu.Unlock()

	if a.accessToken != "" && time.Now().Before(a.tokenExpiry) {
		return a.accessToken, nil
	}

	payload := map[string]string{
		"client_id":     a.cfg.ClientID,
		"client_secret": a.cfg.ClientSecret,
		"grant_type":    "client_credentials",
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return "", err
	}

	url := a.cfg.BaseURL + "/auth/oauth2/token"
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Accept", "application/json")

	resp, err := a.client.Do(req)
	if err != nil {
		return "", fmt.Errorf("airtel: token request failed: %w", err)
	}
	defer resp.Body.Close()
	respBody, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("%w: airtel token request status %d: %s", ErrProviderRejected, resp.StatusCode, string(respBody))
	}

	var tokenResp struct {
		AccessToken string `json:"access_token"`
		ExpiresIn   int    `json:"expires_in"`
	}
	if err := json.Unmarshal(respBody, &tokenResp); err != nil {
		return "", fmt.Errorf("airtel: could not parse token response: %w", err)
	}
	if tokenResp.AccessToken == "" {
		return "", fmt.Errorf("%w: airtel token response had no access_token", ErrProviderRejected)
	}

	a.accessToken = tokenResp.AccessToken
	expiresIn := tokenResp.ExpiresIn
	if expiresIn <= 60 {
		expiresIn = 3600
	}
	a.tokenExpiry = time.Now().Add(time.Duration(expiresIn-60) * time.Second)

	return a.accessToken, nil
}

// RequestToPay implements POST /merchant/v1/payments/ (push USSD prompt to
// the payer's phone). Like MTN, this is asynchronous — a success response
// here only means the request was accepted for processing.
func (a *AirtelProvider) RequestToPay(ctx context.Context, req PaymentRequest) (*PaymentResult, error) {
	if err := validate(req); err != nil {
		return nil, err
	}

	token, err := a.authenticate(ctx)
	if err != nil {
		return nil, err
	}

	payload := map[string]interface{}{
		"reference": req.ExternalID,
		"subscriber": map[string]string{
			"country":  a.cfg.Country,
			"currency": a.cfg.Currency,
			"msisdn":   req.MSISDN,
		},
		"transaction": map[string]interface{}{
			"amount":   req.Amount,
			"country":  a.cfg.Country,
			"currency": a.cfg.Currency,
			"id":       req.ExternalID,
		},
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("airtel: could not encode request: %w", err)
	}

	url := a.cfg.BaseURL + "/merchant/v1/payments/"
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Authorization", "Bearer "+token)
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.Header.Set("Accept", "*/*")
	httpReq.Header.Set("X-Country", a.cfg.Country)
	httpReq.Header.Set("X-Currency", a.cfg.Currency)

	resp, err := a.client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("airtel: payment request failed: %w", err)
	}
	defer resp.Body.Close()
	respBody, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("%w: airtel payment request status %d: %s", ErrProviderRejected, resp.StatusCode, string(respBody))
	}

	var payResp struct {
		Data struct {
			TransactionID string `json:"transaction_id"`
		} `json:"data"`
		Status struct {
			Success bool   `json:"success"`
			Message string `json:"message"`
		} `json:"status"`
	}
	if err := json.Unmarshal(respBody, &payResp); err != nil {
		return nil, fmt.Errorf("airtel: could not parse payment response: %w", err)
	}
	if !payResp.Status.Success {
		return nil, fmt.Errorf("%w: airtel: %s", ErrProviderRejected, payResp.Status.Message)
	}

	referenceID := payResp.Data.TransactionID
	if referenceID == "" {
		// Fall back to our own reference so callers always have something
		// to poll status with, and log context is never empty.
		referenceID = uuid.NewString()
	}

	return &PaymentResult{
		Provider:      a.Name(),
		ReferenceID:   referenceID,
		Status:        StatusPending,
		RawStatusCode: resp.StatusCode,
	}, nil
}

// CheckStatus implements GET /standard/v1/payments/{transactionId}.
func (a *AirtelProvider) CheckStatus(ctx context.Context, referenceID string) (*PaymentResult, error) {
	if referenceID == "" {
		return nil, fmt.Errorf("%w: referenceID is required", ErrInvalidRequest)
	}

	token, err := a.authenticate(ctx)
	if err != nil {
		return nil, err
	}

	url := a.cfg.BaseURL + "/standard/v1/payments/" + referenceID
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Authorization", "Bearer "+token)
	httpReq.Header.Set("Accept", "*/*")
	httpReq.Header.Set("X-Country", a.cfg.Country)
	httpReq.Header.Set("X-Currency", a.cfg.Currency)

	resp, err := a.client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("airtel: status check failed: %w", err)
	}
	defer resp.Body.Close()
	respBody, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("%w: airtel status check %d: %s", ErrProviderRejected, resp.StatusCode, string(respBody))
	}

	var statusResp struct {
		Data struct {
			Transaction struct {
				Status string `json:"status"`
			} `json:"transaction"`
		} `json:"data"`
	}
	if err := json.Unmarshal(respBody, &statusResp); err != nil {
		return nil, fmt.Errorf("airtel: could not parse status response: %w", err)
	}

	status := StatusUnknown
	switch statusResp.Data.Transaction.Status {
	case "TS", "TIP": // Airtel: TS = success, TIP = in progress (kept pending)
		if statusResp.Data.Transaction.Status == "TS" {
			status = StatusSuccess
		} else {
			status = StatusPending
		}
	case "TF":
		status = StatusFailed
	}

	return &PaymentResult{
		Provider:      a.Name(),
		ReferenceID:   referenceID,
		Status:        status,
		RawStatusCode: resp.StatusCode,
	}, nil
}
