package payments

import (
	"fmt"
	"os"
)

// LoadProvidersFromEnv builds every provider whose credentials are present
// in the environment. A provider whose config is incomplete is skipped
// (not an error) so SABA can run with zero, one, or both providers enabled
// depending on what the deployer has configured — this mirrors the
// project's existing "API keys are environment-only" security baseline.
func LoadProvidersFromEnv() (map[string]Provider, []error) {
	providers := make(map[string]Provider)
	var warnings []error

	mtnCfg := MTNConfig{
		BaseURL:           os.Getenv("MTN_MOMO_BASE_URL"),
		SubscriptionKey:   os.Getenv("MTN_MOMO_SUBSCRIPTION_KEY"),
		APIUser:           os.Getenv("MTN_MOMO_API_USER"),
		APIKey:            os.Getenv("MTN_MOMO_API_KEY"),
		TargetEnvironment: os.Getenv("MTN_MOMO_TARGET_ENVIRONMENT"),
	}
	if mtn, err := NewMTNProvider(mtnCfg); err == nil {
		providers["mtn"] = mtn
	} else if err != ErrMissingConfig {
		warnings = append(warnings, fmt.Errorf("mtn: %w", err))
	}

	airtelCfg := AirtelConfig{
		BaseURL:      os.Getenv("AIRTEL_BASE_URL"),
		ClientID:     os.Getenv("AIRTEL_CLIENT_ID"),
		ClientSecret: os.Getenv("AIRTEL_CLIENT_SECRET"),
		Country:      os.Getenv("AIRTEL_COUNTRY"),
		Currency:     os.Getenv("AIRTEL_CURRENCY"),
	}
	if airtel, err := NewAirtelProvider(airtelCfg); err == nil {
		providers["airtel"] = airtel
	} else if err != ErrMissingConfig {
		warnings = append(warnings, fmt.Errorf("airtel: %w", err))
	}

	return providers, warnings
}
