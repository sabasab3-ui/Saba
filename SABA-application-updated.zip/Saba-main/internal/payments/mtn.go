package payments

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sync"
	"time"

	"github.com/google/uuid"
)

// MTNConfig holds the credentials issued by the MTN MoMo Developer Portal
// (momodeveloper.mtn.com) for the Collections product.
//
// Required env vars (see .env.example):
//
//	MTN_MOMO_BASE_URL            e.g. https://sandbox.momodeveloper.mtn.com (sandbox)
//	                                   or https://momodeveloper.mtn.com (production)
//	MTN_MOMO_SUBSCRIPTION_KEY    Ocp-Apim-Subscription-Key for the Collections product
//	MTN_MOMO_API_USER            API user (UUID) created under that subscription
//	MTN_MOMO_API_KEY             API key generated for that API user
//	MTN_MOMO_TARGET_ENVIRONMENT  "sandbox" or the provider-assigned production environment name
type MTNConfig struct {
	BaseURL            string
	SubscriptionKey    string
	APIUser            string
	APIKey             string
	TargetEnvironment  string
}

func (c MTNConfig) valid() bool {
	return c.BaseURL != "" && c.SubscriptionKey != "" && c.APIUser != "" &&
		c.APIKey != "" && c.TargetEnvironment != ""
}

// MTNProvider implements Provider against the MTN MoMo Collections API.
type MTNProvider struct {
	cfg    MTNConfig
	client *http.Client

	mu          sync.Mutex
	accessToken string
	tokenExpiry time.Time
}

// NewMTNProvider builds an MTN MoMo client. It returns ErrMissingConfig if
// any required credential is absent so callers can decide whether to
// register the provider at all.
func NewMTNProvider(cfg MTNConfig) (*MTNProvider, error) {
	if !cfg.valid() {
		return nil, ErrMissingConfig
	}
	return &MTNProvider{
		cfg:    cfg,
		client: &http.Client{Timeout: defaultHTTPTimeout},
	}, nil
}

func (m *MTNProvider) Name() string { return "mtn" }

// authenticate obtains (and caches) a Collections access token via
// POST /collection/token/. Tokens are re-used until ~60s before expiry.
func (m *MTNProvider) authenticate(ctx context.Context) (string, error) {
	m.mu.Lock()
	defer m.mu.Unlock()

	if m.accessToken != "" && time.Now().Before(m.tokenExpiry) {
		return m.accessToken, nil
	}

	url := m.cfg.BaseURL + "/collection/token/"
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, nil)
	if err != nil {
		return "", err
	}

	basic := base64.StdEncoding.EncodeToString([]byte(m.cfg.APIUser + ":" + m.cfg.APIKey))
	req.Header.Set("Authorization", "Basic "+basic)
	req.Header.Set("Ocp-Apim-Subscription-Key", m.cfg.SubscriptionKey)

	resp, err := m.client.Do(req)
	if err != nil {
		return "", fmt.Errorf("mtn: token request failed: %w", err)
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("%w: mtn token request status %d: %s", ErrProviderRejected, resp.StatusCode, string(body))
	}

	var tokenResp struct {
		AccessToken string `json:"access_token"`
		ExpiresIn   int    `json:"expires_in"`
	}
	if err := json.Unmarshal(body, &tokenResp); err != nil {
		return "", fmt.Errorf("mtn: could not parse token response: %w", err)
	}
	if tokenResp.AccessToken == "" {
		return "", fmt.Errorf("%w: mtn token response had no access_token", ErrProviderRejected)
	}

	m.accessToken = tokenResp.AccessToken
	// Refresh a little early so we never fire a request on an expired token.
	expiresIn := tokenResp.ExpiresIn
	if expiresIn <= 60 {
		expiresIn = 3600
	}
	m.tokenExpiry = time.Now().Add(time.Duration(expiresIn-60) * time.Second)

	return m.accessToken, nil
}

// RequestToPay implements POST /collection/v1_0/requesttopay.
// This is asynchronous: a 202 means the prompt was sent to the payer's
// phone, not that money has moved. Call CheckStatus to learn the outcome.
func (m *MTNProvider) RequestToPay(ctx context.Context, req PaymentRequest) (*PaymentResult, error) {
	if err := validate(req); err != nil {
		return nil, err
	}

	token, err := m.authenticate(ctx)
	if err != nil {
		return nil, err
	}

	referenceID := uuid.NewString()

	payload := map[string]interface{}{
		"amount":     req.Amount,
		"currency":   req.Currency,
		"externalId": req.ExternalID,
		"payer": map[string]string{
			"partyIdType": "MSISDN",
			"partyId":     req.MSISDN,
		},
		"payerMessage": req.PayerMessage,
		"payeeNote":    req.PayeeNote,
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return nil, fmt.Errorf("mtn: could not encode request: %w", err)
	}

	url := m.cfg.BaseURL + "/collection/v1_0/requesttopay"
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Authorization", "Bearer "+token)
	httpReq.Header.Set("Ocp-Apim-Subscription-Key", m.cfg.SubscriptionKey)
	httpReq.Header.Set("X-Reference-Id", referenceID)
	httpReq.Header.Set("X-Target-Environment", m.cfg.TargetEnvironment)
	httpReq.Header.Set("Content-Type", "application/json")

	resp, err := m.client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("mtn: requesttopay call failed: %w", err)
	}
	defer resp.Body.Close()
	respBody, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusAccepted {
		return nil, fmt.Errorf("%w: mtn requesttopay status %d: %s", ErrProviderRejected, resp.StatusCode, string(respBody))
	}

	return &PaymentResult{
		Provider:      m.Name(),
		ReferenceID:   referenceID,
		Status:        StatusPending,
		RawStatusCode: resp.StatusCode,
	}, nil
}

// CheckStatus implements GET /collection/v1_0/requesttopay/{referenceId}.
func (m *MTNProvider) CheckStatus(ctx context.Context, referenceID string) (*PaymentResult, error) {
	if referenceID == "" {
		return nil, fmt.Errorf("%w: referenceID is required", ErrInvalidRequest)
	}

	token, err := m.authenticate(ctx)
	if err != nil {
		return nil, err
	}

	url := m.cfg.BaseURL + "/collection/v1_0/requesttopay/" + referenceID
	httpReq, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	httpReq.Header.Set("Authorization", "Bearer "+token)
	httpReq.Header.Set("Ocp-Apim-Subscription-Key", m.cfg.SubscriptionKey)
	httpReq.Header.Set("X-Target-Environment", m.cfg.TargetEnvironment)

	resp, err := m.client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("mtn: status check failed: %w", err)
	}
	defer resp.Body.Close()
	respBody, _ := io.ReadAll(resp.Body)

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("%w: mtn status check %d: %s", ErrProviderRejected, resp.StatusCode, string(respBody))
	}

	var statusResp struct {
		Status string `json:"status"`
	}
	if err := json.Unmarshal(respBody, &statusResp); err != nil {
		return nil, fmt.Errorf("mtn: could not parse status response: %w", err)
	}

	status := StatusUnknown
	switch statusResp.Status {
	case "SUCCESSFUL":
		status = StatusSuccess
	case "FAILED":
		status = StatusFailed
	case "PENDING":
		status = StatusPending
	}

	return &PaymentResult{
		Provider:      m.Name(),
		ReferenceID:   referenceID,
		Status:        status,
		RawStatusCode: resp.StatusCode,
	}, nil
}
