package agent

import (
	"context"
	"io"
	"net/http"
	"net/url"
	"strings"
	"testing"
)

type roundTripFunc func(*http.Request) (*http.Response, error)

func (f roundTripFunc) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func TestWebScraperTool(t *testing.T) {
	tool := &WebScraperTool{Client: &http.Client{
		Transport: roundTripFunc(func(r *http.Request) (*http.Response, error) {
			return &http.Response{
				StatusCode: http.StatusOK,
				Body:       io.NopCloser(strings.NewReader(`<html><head><title>SABA Test</title><script>ignore()</script></head><body><h1>Hello from SABA</h1><p>Web scraping works.</p></body></html>`)),
				Header:     make(http.Header),
				Request:    r,
			}, nil
		}),
	}}

	text, err := tool.Scrape(context.Background(), "https://example.com")
	if err != nil {
		t.Fatalf("scraper failed: %v", err)
	}
	if !strings.Contains(text, "Hello from SABA") || strings.Contains(text, "ignore()") {
		t.Fatalf("unexpected extracted text: %q", text)
	}
}

func TestWebScraperRejectsPrivateHosts(t *testing.T) {
	for _, raw := range []string{"http://127.0.0.1:8080", "http://localhost:8080", "http://10.0.0.1"} {
		u, _ := url.Parse(raw)
		if !isPrivateHost(u.Hostname()) {
			t.Fatalf("expected private host to be rejected: %s", raw)
		}
	}
}
