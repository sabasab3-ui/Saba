package agent

import (
	"context"
	"fmt"
	"log"
	"strings"

	"github.com/sabasab3-ui/saba/internal/capabilities"
	"github.com/sabasab3-ui/saba/internal/i18n"
	"github.com/sabasab3-ui/saba/internal/modes"
	"github.com/sabasab3-ui/saba/internal/payments"
)

type Agent struct {
	Name        string
	Model       string
	Memory      *Memory
	Tools       *ToolKit
	Language    string
	Description string
}

func NewAgent(name, model, language string) *Agent {
	tools := NewToolKit()

	providers, warnings := payments.LoadProvidersFromEnv()
	for _, w := range warnings {
		log.Printf("payments: %v", w)
	}

	// Register built-in SABA tools
	tools.Register(&InventoryTool{})
	tools.Register(&OrderTool{})
	tools.Register(NewPaymentTool(providers))
	tools.Register(&KnowledgeTool{})
	tools.Register(&WebScraperTool{})

	return &Agent{
		Name:        name,
		Model:       model,
		Memory:      NewMemory(),
		Tools:       tools,
		Language:    language,
		Description: "SABA - Smart Automation for Business in Africa",
	}
}

type Message struct {
	UserID    string
	Content   string
	Timestamp int64
	Language  string
}

type Response struct {
	Mode               string
	Text               string
	Action             string
	Params             map[string]interface{}
	Confidence         float64
	Capability         string
	CapabilityGuidance string
}

func (a *Agent) Process(ctx context.Context, msg *Message) (*Response, error) {
	a.Memory.AddTurn(msg.UserID, msg.Content)

	mode := modes.Detect(msg.Content)
	capability := capabilities.Detect(msg.Content)

	text := strings.ToLower(strings.TrimSpace(msg.Content))

	// Simple task detection
	task := ""

	switch {
	case strings.Contains(text, "inventory"):
		task = "inventory"

	case strings.Contains(text, "order"):
		task = "orders"

	case strings.Contains(text, "payment"):
		task = "payments"

	case strings.Contains(text, "scrape"):
		task = "scraper"
	}

	// No task detected: normal response
	if task == "" {
		lang := i18n.Detect(msg.Language)
		return &Response{
			Text:               fmt.Sprintf("SABA [%s mode]: %s\n\nGuidance: %s", mode.Mode, msg.Content, i18n.Guidance(string(mode.Mode), lang)),
			Mode:               string(mode.Mode),
			Action:             "echo",
			Params:             map[string]interface{}{},
			Confidence:         0.5,
			Capability:         string(capability.Capability),
			CapabilityGuidance: capabilities.Guidance(capability.Capability),
		}, nil
	}

	// Natural-language task detection should not silently execute a business
	// operation without the parameters required by that operation. Return an
	// actionable request instead; ExecuteTask remains the explicit execution API.
	return &Response{
		Text:               fmt.Sprintf("SABA [%s mode] detected the %s task. Please provide the required action and parameters before execution.", mode.Mode, task),
		Mode:               string(mode.Mode),
		Action:             task,
		Params:             map[string]interface{}{},
		Confidence:         0.9,
		Capability:         string(capability.Capability),
		CapabilityGuidance: capabilities.Guidance(capability.Capability),
	}, nil
}

func (a *Agent) ExecuteTask(
	ctx context.Context,
	taskName string,
	params map[string]interface{},
) (map[string]interface{}, error) {

	tool, exists := a.Tools.Get(taskName)

	if !exists {
		return nil, fmt.Errorf("tool not found: %s", taskName)
	}

	err := tool.Execute(ctx, params)

	if err != nil {
		return nil, err
	}

	return map[string]interface{}{
		"status": "ok",
		"task":   taskName,
	}, nil
}

func (a *Agent) GetStatus() map[string]interface{} {
	return map[string]interface{}{
		"name":        a.Name,
		"model":       a.Model,
		"language":    a.Language,
		"status":      "active",
		"description": a.Description,
	}
}
