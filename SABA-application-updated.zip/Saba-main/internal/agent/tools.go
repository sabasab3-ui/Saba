package agent

import (
	"context"
	"fmt"
	"strconv"
	"sync"

	"github.com/sabasab3-ui/saba/internal/database"
	"github.com/sabasab3-ui/saba/internal/knowledge"
	"github.com/sabasab3-ui/saba/internal/payments"
)

type Tool interface {
	Name() string
	Description() string
	Execute(ctx context.Context, params map[string]interface{}) error
}

type ToolKit struct {
	mu    sync.RWMutex
	tools map[string]Tool
}

func NewToolKit() *ToolKit {
	return &ToolKit{
		tools: make(map[string]Tool),
	}
}

func (tk *ToolKit) Register(tool Tool) {
	tk.mu.Lock()
	defer tk.mu.Unlock()
	tk.tools[tool.Name()] = tool
}

func (tk *ToolKit) Get(name string) (Tool, bool) {
	tk.mu.RLock()
	defer tk.mu.RUnlock()

	tool, exists := tk.tools[name]
	return tool, exists
}

func (tk *ToolKit) List() []Tool {
	tk.mu.RLock()
	defer tk.mu.RUnlock()

	tools := make([]Tool, 0, len(tk.tools))
	for _, tool := range tk.tools {
		tools = append(tools, tool)
	}

	return tools
}

type InventoryTool struct{}

func (t *InventoryTool) Name() string {
	return "inventory"
}

func (t *InventoryTool) Description() string {
	return "Manage and query inventory levels"
}

func (t *InventoryTool) Execute(ctx context.Context, params map[string]interface{}) error {
	action, ok := params["action"].(string)
	if !ok {
		return fmt.Errorf("missing action parameter")
	}

	db, err := database.OpenInventoryDB("inventory.db")
	if err != nil {
		return fmt.Errorf("open inventory database: %w", err)
	}
	defer db.Close()

	switch action {
	case "check":
		name, ok := params["name"].(string)
		if !ok || name == "" {
			return fmt.Errorf("missing product name")
		}

		product, err := db.CheckProduct(name)
		if err != nil {
			return err
		}

		if product == nil {
			return fmt.Errorf("product not found: %s", name)
		}

		return nil

	case "update":
		name, ok := params["name"].(string)
		if !ok || name == "" {
			return fmt.Errorf("missing product name")
		}

		v, ok := params["quantity"]
		if !ok {
			return fmt.Errorf("missing quantity")
		}

		var quantity int
		switch n := v.(type) {
		case int:
			quantity = n
		case float64:
			quantity = int(n)
		default:
			return fmt.Errorf("invalid quantity")
		}

		return db.UpdateQuantity(name, quantity)

	default:
		return fmt.Errorf("unknown action: %s", action)
	}
}

type OrderTool struct{}

func (t *OrderTool) Name() string {
	return "orders"
}

func (t *OrderTool) Description() string {
	return "Create, view, and manage orders"
}

func (t *OrderTool) Execute(ctx context.Context, params map[string]interface{}) error {
	action, ok := params["action"].(string)
	if !ok {
		return fmt.Errorf("missing action parameter")
	}

	db, err := database.OpenOrderDB("orders.db")
	if err != nil {
		return fmt.Errorf("open orders database: %w", err)
	}
	defer db.Close()

	switch action {

	case "create":
		customer, ok := params["customer"].(string)
		if !ok || customer == "" {
			return fmt.Errorf("missing customer")
		}

		product, ok := params["product"].(string)
		if !ok || product == "" {
			return fmt.Errorf("missing product")
		}

		v, ok := params["quantity"]
		if !ok {
			return fmt.Errorf("missing quantity")
		}

		var quantity int

		switch n := v.(type) {
		case int:
			quantity = n
		case float64:
			quantity = int(n)
		default:
			return fmt.Errorf("invalid quantity")
		}

		_, err := db.CreateOrder(customer, product, quantity)
		if err != nil {
			return err
		}

		return nil

	case "list":
		_, err := db.ListOrders()
		if err != nil {
			return err
		}

		return nil

	case "update":
		v, ok := params["id"]
		if !ok {
			return fmt.Errorf("missing order id")
		}

		var id int64

		switch n := v.(type) {
		case int:
			id = int64(n)
		case int64:
			id = n
		case float64:
			id = int64(n)
		default:
			return fmt.Errorf("invalid order id")
		}

		status, ok := params["status"].(string)
		if !ok || status == "" {
			return fmt.Errorf("missing status")
		}

		return db.UpdateStatus(id, status)

	default:
		return fmt.Errorf("unknown action: %s", action)
	}
}

// PaymentTool executes real mobile-money collections through MTN MoMo and/or
// Airtel Money. It replaces the earlier provider-name-validation stub: a
// successful Execute now means the request was actually submitted to the
// provider, not merely that "mtn"/"airtel" was spelled correctly.
//
// Providers are injected rather than constructed inline so the tool has no
// direct dependency on environment variables or HTTP clients — see
// NewPaymentTool and payments.LoadProvidersFromEnv.
type PaymentTool struct {
	providers map[string]payments.Provider
}

// NewPaymentTool wires up a PaymentTool from a set of already-configured
// providers (as returned by payments.LoadProvidersFromEnv). A nil/empty map
// is valid — the tool will simply report every provider as unconfigured
// until credentials are supplied.
func NewPaymentTool(providers map[string]payments.Provider) *PaymentTool {
	return &PaymentTool{providers: providers}
}

func (t *PaymentTool) Name() string {
	return "payments"
}

func (t *PaymentTool) Description() string {
	return "Initiate or check a real MTN Mobile Money / Airtel Money collection (request-to-pay)"
}

// Execute expects params:
//
//	provider     "mtn" | "airtel"                      (required)
//	action       "request" (default) | "status"
//	amount       decimal string, e.g. "1500.00"         (required for "request")
//	currency     e.g. "UGX"                             (required for "request")
//	msisdn       payer phone, digits only e.g. 256...   (required for "request")
//	externalId   caller's own order/invoice reference   (required for "request")
//	payerMessage optional note shown to the payer
//	payeeNote    optional note kept for the payee
//	referenceId  provider reference to poll             (required for "status")
//
// Results are written back into params (referenceId, status, rawStatusCode)
// since the Tool interface only reports success/failure via error — this
// keeps the change minimal against the existing execution path while still
// surfacing the real provider response to whatever called Execute.
func (t *PaymentTool) Execute(ctx context.Context, params map[string]interface{}) error {
	providerName, ok := params["provider"].(string)
	if !ok || providerName == "" {
		return fmt.Errorf("missing provider parameter")
	}

	provider, ok := t.providers[providerName]
	if !ok {
		switch providerName {
		case "mtn", "airtel":
			return fmt.Errorf(
				"%s is not configured: missing credentials in the environment (see .env.example)",
				providerName,
			)
		default:
			return fmt.Errorf("unknown provider: %s", providerName)
		}
	}

	action, _ := params["action"].(string)
	if action == "" {
		action = "request"
	}

	switch action {
	case "status":
		referenceID, _ := params["referenceId"].(string)
		if referenceID == "" {
			return fmt.Errorf("missing referenceId for status check")
		}

		result, err := provider.CheckStatus(ctx, referenceID)
		if err != nil {
			return err
		}

		if db, dbErr := database.OpenPaymentDB("payments.db"); dbErr == nil {
			defer db.Close()
			// Best-effort: a status check should still return the live
			// provider result to the caller even if the local write fails.
			_, _ = db.UpdateStatusByReference(providerName, referenceID, string(result.Status))
		}

		params["referenceId"] = result.ReferenceID
		params["status"] = string(result.Status)
		params["rawStatusCode"] = result.RawStatusCode
		return nil

	case "request":
		amount, _ := params["amount"].(string)
		currency, _ := params["currency"].(string)
		msisdn, _ := params["msisdn"].(string)
		externalID, _ := params["externalId"].(string)
		payerMessage, _ := params["payerMessage"].(string)
		payeeNote, _ := params["payeeNote"].(string)

		// Idempotency: reserve this (provider, externalId) pair in the
		// database *before* calling the provider. If a caller retries the
		// same order/invoice reference (network hiccup, duplicate click),
		// this rejects the second attempt instead of pushing a second
		// payment prompt to the payer's phone.
		db, dbErr := database.OpenPaymentDB("payments.db")
		if dbErr != nil {
			return fmt.Errorf("open payments database: %w", dbErr)
		}
		defer db.Close()

		if existing, getErr := db.GetByExternalID(providerName, externalID); getErr == nil {
			params["referenceId"] = existing.ReferenceID
			params["status"] = existing.Status
			params["duplicate"] = true
			return nil
		}

		result, err := provider.RequestToPay(ctx, payments.PaymentRequest{
			Amount:       amount,
			Currency:     currency,
			MSISDN:       msisdn,
			ExternalID:   externalID,
			PayerMessage: payerMessage,
			PayeeNote:    payeeNote,
		})
		if err != nil {
			return err
		}

		if _, err := db.CreatePayment(providerName, externalID, result.ReferenceID, msisdn, amount, currency, string(result.Status)); err != nil {
			if err == database.ErrDuplicatePayment {
				// Lost a race with a concurrent identical request: treat as
				// success and report the winner's reference rather than
				// erroring after a real payment prompt was already sent.
				if existing, getErr := db.GetByExternalID(providerName, externalID); getErr == nil {
					params["referenceId"] = existing.ReferenceID
					params["status"] = existing.Status
					params["duplicate"] = true
					return nil
				}
			}
			return fmt.Errorf("payment succeeded but could not be recorded: %w", err)
		}

		params["referenceId"] = result.ReferenceID
		params["status"] = string(result.Status)
		params["rawStatusCode"] = result.RawStatusCode
		return nil

	default:
		return fmt.Errorf("unknown action: %s", action)
	}
}

// KnowledgeTool answers questions against SABA's curated local reference
// data (mobile money fees, crop calendar) — see internal/knowledge.
type KnowledgeTool struct{}

func (t *KnowledgeTool) Name() string {
	return "knowledge"
}

func (t *KnowledgeTool) Description() string {
	return "Look up curated local reference data: mobile money fees, crop calendar"
}

// Execute expects params:
//
//	topic     "momo_fee" | "crop_calendar"
//	provider  "mtn" | "airtel"           (required for momo_fee)
//	amount    UGX amount as number       (required for momo_fee)
//	crop      crop name, e.g. "maize"    (required for crop_calendar)
//
// Results are written back into params["result"] as JSON-serializable data
// (same pattern as PaymentTool), since the Tool interface itself only
// reports success/failure.
func (t *KnowledgeTool) Execute(ctx context.Context, params map[string]interface{}) error {
	topic, _ := params["topic"].(string)

	switch topic {
	case "momo_fee":
		provider, _ := params["provider"].(string)
		if provider == "" {
			return fmt.Errorf("missing provider")
		}

		var amount int
		switch v := params["amount"].(type) {
		case int:
			amount = v
		case float64:
			amount = int(v)
		case string:
			parsed, err := strconv.Atoi(v)
			if err != nil {
				return fmt.Errorf("invalid amount: %w", err)
			}
			amount = parsed
		default:
			return fmt.Errorf("missing amount")
		}

		fee := knowledge.FeeFor(provider, amount)
		if fee == nil {
			return fmt.Errorf("no fee bracket found for %s at %d UGX", provider, amount)
		}
		params["result"] = fee
		return nil

	case "crop_calendar":
		crop, _ := params["crop"].(string)
		if crop == "" {
			return fmt.Errorf("missing crop")
		}
		entries := knowledge.CropsFor(crop)
		if len(entries) == 0 {
			return fmt.Errorf("no calendar entries found for %q", crop)
		}
		params["result"] = entries
		return nil

	default:
		return fmt.Errorf("unknown topic: %s (expected momo_fee or crop_calendar)", topic)
	}
}
