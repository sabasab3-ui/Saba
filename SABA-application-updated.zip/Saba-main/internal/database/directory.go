package database

import (
	"context"
	"database/sql"
	"fmt"
	"strings"
	"time"

	_ "modernc.org/sqlite"
)

// DirectoryDB is the beginning of SABA's network effect: businesses using
// SABA can list what they sell/need so other SABA users can find them —
// moving SABA from "a tool one business uses alone" toward "a place
// businesses find each other." Deliberately simple (keyword match on
// category/location) rather than anything resembling a recommendation
// engine — that's a reasonable v2, not a v1 requirement.
type DirectoryDB struct {
	db *sql.DB
}

type Listing struct {
	ID          int64  `json:"id"`
	BusinessName string `json:"business_name"`
	Category    string `json:"category"`    // free text, e.g. "maize supplier", "tailoring"
	Region      string `json:"region"`       // e.g. "Soroti", "Kampala"
	Contact     string `json:"contact"`      // phone number or other contact the owner wants shared
	Kind        string `json:"kind"`         // "supply" (offering) | "demand" (looking for)
	Description string `json:"description"`
	CreatedAt   int64  `json:"created_at"`
}

func OpenDirectoryDB(path string) (*DirectoryDB, error) {
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, err
	}

	db.SetMaxOpenConns(1)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	_, err = db.ExecContext(ctx, `
CREATE TABLE IF NOT EXISTS directory_listings (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	business_name TEXT NOT NULL,
	category TEXT NOT NULL,
	region TEXT NOT NULL,
	contact TEXT NOT NULL,
	kind TEXT NOT NULL DEFAULT 'supply',
	description TEXT NOT NULL DEFAULT '',
	created_at INTEGER NOT NULL
)
`)
	if err != nil {
		db.Close()
		return nil, fmt.Errorf("create directory_listings table: %w", err)
	}

	return &DirectoryDB{db: db}, nil
}

func (d *DirectoryDB) Register(l Listing) (*Listing, error) {
	if l.BusinessName == "" || l.Category == "" || l.Contact == "" {
		return nil, fmt.Errorf("businessName, category and contact are required")
	}
	if l.Kind != "supply" && l.Kind != "demand" {
		l.Kind = "supply"
	}

	now := time.Now().Unix()
	result, err := d.db.Exec(`
INSERT INTO directory_listings (business_name, category, region, contact, kind, description, created_at)
VALUES (?, ?, ?, ?, ?, ?, ?)
`, l.BusinessName, l.Category, l.Region, l.Contact, l.Kind, l.Description, now)
	if err != nil {
		return nil, err
	}

	id, err := result.LastInsertId()
	if err != nil {
		return nil, err
	}
	l.ID = id
	l.CreatedAt = now
	return &l, nil
}

// Search does a simple case-insensitive substring match on category and
// region — deliberately basic (no fuzzy matching, no ranking) so it's
// predictable and cheap to run against a growing listings table.
func (d *DirectoryDB) Search(category, region, kind string) ([]Listing, error) {
	query := `
SELECT id, business_name, category, region, contact, kind, description, created_at
FROM directory_listings
WHERE 1=1
`
	var args []interface{}

	if category != "" {
		query += " AND category LIKE ?"
		args = append(args, "%"+strings.ToLower(category)+"%")
	}
	if region != "" {
		query += " AND region LIKE ?"
		args = append(args, "%"+strings.ToLower(region)+"%")
	}
	if kind != "" {
		query += " AND kind = ?"
		args = append(args, kind)
	}
	query += " ORDER BY id DESC LIMIT 50"

	rows, err := d.db.Query(query, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var listings []Listing
	for rows.Next() {
		var l Listing
		if err := rows.Scan(&l.ID, &l.BusinessName, &l.Category, &l.Region, &l.Contact, &l.Kind, &l.Description, &l.CreatedAt); err != nil {
			return nil, err
		}
		listings = append(listings, l)
	}
	return listings, rows.Err()
}

func (d *DirectoryDB) Close() error {
	return d.db.Close()
}
