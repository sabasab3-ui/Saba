package database

import (
	"path/filepath"
	"testing"
)

func TestInventoryCRUD(t *testing.T) {
	db, err := OpenInventoryDB(filepath.Join(t.TempDir(), "inventory.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	if err := db.AddProduct("coffee", 10); err != nil {
		t.Fatal(err)
	}
	product, err := db.CheckProduct("coffee")
	if err != nil {
		t.Fatal(err)
	}
	if product.Quantity != 10 {
		t.Fatalf("expected 10, got %d", product.Quantity)
	}
	if err := db.UpdateQuantity("coffee", 7); err != nil {
		t.Fatal(err)
	}
	product, err = db.CheckProduct("coffee")
	if err != nil {
		t.Fatal(err)
	}
	if product.Quantity != 7 {
		t.Fatalf("expected 7, got %d", product.Quantity)
	}
}

func TestOrderCRUD(t *testing.T) {
	db, err := OpenOrderDB(filepath.Join(t.TempDir(), "orders.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	order, err := db.CreateOrder("Customer", "coffee", 2)
	if err != nil {
		t.Fatal(err)
	}
	if order.Status != "pending" {
		t.Fatalf("expected pending, got %s", order.Status)
	}
	if err := db.UpdateStatus(order.ID, "paid"); err != nil {
		t.Fatal(err)
	}
	got, err := db.GetOrder(order.ID)
	if err != nil {
		t.Fatal(err)
	}
	if got.Status != "paid" {
		t.Fatalf("expected paid, got %s", got.Status)
	}
	orders, err := db.ListOrders()
	if err != nil {
		t.Fatal(err)
	}
	if len(orders) != 1 {
		t.Fatalf("expected 1 order, got %d", len(orders))
	}
}
