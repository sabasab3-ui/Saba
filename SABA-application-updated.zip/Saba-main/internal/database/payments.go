package database

import (
	"context"
	"database/sql"
	"fmt"
	"strconv"
	"time"

	_ "modernc.org/sqlite"
)

// PaymentDB persists every payment attempt SABA makes or hears about, so
// nothing is lost on restart and every webhook/poll result has somewhere
// durable to land.
type PaymentDB struct {
	db *sql.DB
}

type Payment struct {
	ID            int64  `json:"id"`
	Provider      string `json:"provider"`       // "mtn" | "airtel"
	ExternalID    string `json:"external_id"`     // SABA's own order/invoice reference
	ReferenceID   string `json:"reference_id"`    // provider-side transaction id
	MSISDN        string `json:"msisdn"`
	Amount        string `json:"amount"`
	Currency      string `json:"currency"`
	Status        string `json:"status"`          // PENDING | SUCCESSFUL | FAILED | UNKNOWN
	CreatedAt     int64  `json:"created_at"`
	UpdatedAt     int64  `json:"updated_at"`
}

func OpenPaymentDB(path string) (*PaymentDB, error) {
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, err
	}

	db.SetMaxOpenConns(1)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	_, err = db.ExecContext(ctx, `
CREATE TABLE IF NOT EXISTS payments (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	provider TEXT NOT NULL,
	external_id TEXT NOT NULL,
	reference_id TEXT NOT NULL,
	msisdn TEXT NOT NULL,
	amount TEXT NOT NULL,
	currency TEXT NOT NULL,
	status TEXT NOT NULL DEFAULT 'PENDING',
	created_at INTEGER NOT NULL,
	updated_at INTEGER NOT NULL,
	UNIQUE(provider, external_id),
	UNIQUE(provider, reference_id)
)
`)
	if err != nil {
		db.Close()
		return nil, fmt.Errorf("create payments table: %w", err)
	}

	return &PaymentDB{db: db}, nil
}

// CreatePayment records a new request-to-pay attempt. The UNIQUE constraint
// on (provider, external_id) means calling this twice with the same
// external_id (e.g. a retried HTTP request) returns ErrDuplicatePayment
// instead of silently creating a second payment attempt for the same order.
func (p *PaymentDB) CreatePayment(provider, externalID, referenceID, msisdn, amount, currency, status string) (*Payment, error) {
	if provider == "" || externalID == "" || referenceID == "" {
		return nil, fmt.Errorf("provider, externalID and referenceID are required")
	}

	now := time.Now().Unix()

	result, err := p.db.Exec(`
INSERT INTO payments
(provider, external_id, reference_id, msisdn, amount, currency, status, created_at, updated_at)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
`, provider, externalID, referenceID, msisdn, amount, currency, status, now, now)

	if err != nil {
		if isUniqueConstraintErr(err) {
			return nil, ErrDuplicatePayment
		}
		return nil, err
	}

	id, err := result.LastInsertId()
	if err != nil {
		return nil, err
	}

	return &Payment{
		ID: id, Provider: provider, ExternalID: externalID, ReferenceID: referenceID,
		MSISDN: msisdn, Amount: amount, Currency: currency, Status: status,
		CreatedAt: now, UpdatedAt: now,
	}, nil
}

// UpdateStatusByReference is the idempotent update path used by both the
// webhook handler and the status-polling path: setting the same status
// twice (e.g. a webhook delivered more than once, which providers do not
// guarantee against) is a safe no-op, not a double-processed payment.
func (p *PaymentDB) UpdateStatusByReference(provider, referenceID, status string) (*Payment, error) {
	if status == "" {
		return nil, fmt.Errorf("status is required")
	}

	_, err := p.db.Exec(`
UPDATE payments
SET status = ?, updated_at = ?
WHERE provider = ? AND reference_id = ?
`, status, time.Now().Unix(), provider, referenceID)
	if err != nil {
		return nil, err
	}

	return p.GetByReference(provider, referenceID)
}

func (p *PaymentDB) GetByReference(provider, referenceID string) (*Payment, error) {
	payment := &Payment{}

	err := p.db.QueryRow(`
SELECT id, provider, external_id, reference_id, msisdn, amount, currency, status, created_at, updated_at
FROM payments
WHERE provider = ? AND reference_id = ?
`, provider, referenceID).Scan(
		&payment.ID, &payment.Provider, &payment.ExternalID, &payment.ReferenceID,
		&payment.MSISDN, &payment.Amount, &payment.Currency, &payment.Status,
		&payment.CreatedAt, &payment.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}

	return payment, nil
}

func (p *PaymentDB) GetByExternalID(provider, externalID string) (*Payment, error) {
	payment := &Payment{}

	err := p.db.QueryRow(`
SELECT id, provider, external_id, reference_id, msisdn, amount, currency, status, created_at, updated_at
FROM payments
WHERE provider = ? AND external_id = ?
`, provider, externalID).Scan(
		&payment.ID, &payment.Provider, &payment.ExternalID, &payment.ReferenceID,
		&payment.MSISDN, &payment.Amount, &payment.Currency, &payment.Status,
		&payment.CreatedAt, &payment.UpdatedAt,
	)
	if err != nil {
		return nil, err
	}

	return payment, nil
}

// ListByMSISDN returns a user's own payment history, most recent first —
// the basis for a simple transaction-transparency view: what was
// attempted, when, and its current status. This is deliberately scoped to
// one phone number so a user (or the mobile app on their behalf) can only
// ever see their own transactions, never anyone else's.
func (p *PaymentDB) ListByMSISDN(msisdn string, limit int) ([]Payment, error) {
	if msisdn == "" {
		return nil, fmt.Errorf("msisdn is required")
	}
	if limit <= 0 {
		limit = 50
	}

	rows, err := p.db.Query(`
SELECT id, provider, external_id, reference_id, msisdn, amount, currency, status, created_at, updated_at
FROM payments
WHERE msisdn = ?
ORDER BY id DESC
LIMIT ?
`, msisdn, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var payments []Payment
	for rows.Next() {
		var payment Payment
		if err := rows.Scan(
			&payment.ID, &payment.Provider, &payment.ExternalID, &payment.ReferenceID,
			&payment.MSISDN, &payment.Amount, &payment.Currency, &payment.Status,
			&payment.CreatedAt, &payment.UpdatedAt,
		); err != nil {
			return nil, err
		}
		payments = append(payments, payment)
	}
	return payments, rows.Err()
}

func (p *PaymentDB) ListPayments(limit int) ([]Payment, error) {
	if limit <= 0 {
		limit = 50
	}

	rows, err := p.db.Query(`
SELECT id, provider, external_id, reference_id, msisdn, amount, currency, status, created_at, updated_at
FROM payments
ORDER BY id DESC
LIMIT ?
`, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var payments []Payment
	for rows.Next() {
		var payment Payment
		if err := rows.Scan(
			&payment.ID, &payment.Provider, &payment.ExternalID, &payment.ReferenceID,
			&payment.MSISDN, &payment.Amount, &payment.Currency, &payment.Status,
			&payment.CreatedAt, &payment.UpdatedAt,
		); err != nil {
			return nil, err
		}
		payments = append(payments, payment)
	}

	return payments, rows.Err()
}

// Summary returns counts by status, used by the admin summary endpoint.
func (p *PaymentDB) Summary() (map[string]int, error) {
	rows, err := p.db.Query(`SELECT status, COUNT(*) FROM payments GROUP BY status`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	out := make(map[string]int)
	for rows.Next() {
		var status string
		var count int
		if err := rows.Scan(&status, &count); err != nil {
			return nil, err
		}
		out[status] = count
	}
	return out, rows.Err()
}

// RevenueSummary aggregates successful-payment amounts into the numbers an
// admin dashboard actually wants to see. "Available balance" here is total
// successful revenue minus refunds — SABA has no payout/withdrawal flow
// built yet, so this is gross available funds, not a bank-confirmed
// settled balance.
type RevenueSummary struct {
	TodayEarnings      float64 `json:"today_earnings"`
	MonthEarnings      float64 `json:"month_earnings"`
	SuccessfulPayments int     `json:"successful_payments"`
	RefundedAmount     float64 `json:"refunded_amount"`
	RefundedCount      int     `json:"refunded_count"`
	AvailableBalance   float64 `json:"available_balance"`
}

func (p *PaymentDB) RevenueSummary() (*RevenueSummary, error) {
	now := time.Now()
	todayStart := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location()).Unix()
	monthStart := time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, now.Location()).Unix()

	rows, err := p.db.Query(`
SELECT amount, status, created_at
FROM payments
WHERE status = 'SUCCESSFUL' OR status = 'REFUNDED'
`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	summary := &RevenueSummary{}
	for rows.Next() {
		var amountStr, status string
		var createdAt int64
		if err := rows.Scan(&amountStr, &status, &createdAt); err != nil {
			return nil, err
		}
		amount, parseErr := strconv.ParseFloat(amountStr, 64)
		if parseErr != nil {
			continue // skip malformed amounts rather than fail the whole summary
		}

		switch status {
		case "SUCCESSFUL":
			summary.SuccessfulPayments++
			summary.AvailableBalance += amount
			if createdAt >= monthStart {
				summary.MonthEarnings += amount
			}
			if createdAt >= todayStart {
				summary.TodayEarnings += amount
			}
		case "REFUNDED":
			summary.RefundedCount++
			summary.RefundedAmount += amount
			summary.AvailableBalance -= amount
		}
	}

	return summary, rows.Err()
}

func (p *PaymentDB) Close() error {
	return p.db.Close()
}

var ErrDuplicatePayment = fmt.Errorf("payment already recorded for this provider+externalId")

// isUniqueConstraintErr checks for SQLite's unique-constraint error without
// importing a driver-specific error type, since modernc.org/sqlite's error
// surface is a plain string-wrapped error.
func isUniqueConstraintErr(err error) bool {
	if err == nil {
		return false
	}
	msg := err.Error()
	return contains(msg, "UNIQUE constraint failed")
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && (func() bool {
		for i := 0; i+len(substr) <= len(s); i++ {
			if s[i:i+len(substr)] == substr {
				return true
			}
		}
		return false
	})()
}
