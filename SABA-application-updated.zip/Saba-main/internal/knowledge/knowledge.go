// Package knowledge holds SABA's curated, Uganda-specific reference data —
// the thing a generic web-search-backed LLM can't reliably replicate:
// current local costs, seasonal calendars, and fee structures that change
// slowly but matter a lot to the people SABA is built for.
//
// STATUS: seeded with a small, illustrative starting set so the shape of
// the feature is real and wired end-to-end. The actual numbers below need
// an owner to keep them current — treat them as a starting scaffold, not
// verified live prices. A future version should pull crop prices from a
// real source (e.g. Uganda's Ministry of Agriculture / FEWS NET market
// bulletins) rather than a hand-maintained map.
package knowledge

import "strings"

type MobileMoneyFee struct {
	Provider    string
	RangeLow    int    // UGX, inclusive lower bound of the transaction range
	RangeHigh   int    // UGX, inclusive upper bound (0 = no upper bound)
	SendFee     int    // UGX
	WithdrawFee int    // UGX
	Note        string
}

// MobileMoneyFees is illustrative — MTN and Airtel both revise their fee
// tables periodically. Verify against the providers' current published
// tariffs before surfacing these numbers to a user making a real decision.
var MobileMoneyFees = []MobileMoneyFee{
	{Provider: "mtn", RangeLow: 0, RangeHigh: 2500, SendFee: 100, WithdrawFee: 330, Note: "small transactions"},
	{Provider: "mtn", RangeLow: 2501, RangeHigh: 5000, SendFee: 220, WithdrawFee: 550, Note: ""},
	{Provider: "mtn", RangeLow: 5001, RangeHigh: 15000, SendFee: 440, WithdrawFee: 1100, Note: ""},
	{Provider: "airtel", RangeLow: 0, RangeHigh: 2500, SendFee: 100, WithdrawFee: 330, Note: "small transactions"},
	{Provider: "airtel", RangeLow: 2501, RangeHigh: 5000, SendFee: 220, WithdrawFee: 550, Note: ""},
	{Provider: "airtel", RangeLow: 5001, RangeHigh: 15000, SendFee: 440, WithdrawFee: 1100, Note: ""},
}

// FeeFor returns the matching fee bracket for a given provider and amount,
// or nil if the amount falls outside the seeded ranges.
func FeeFor(provider string, amountUGX int) *MobileMoneyFee {
	provider = strings.ToLower(provider)
	for i := range MobileMoneyFees {
		f := MobileMoneyFees[i]
		if f.Provider != provider {
			continue
		}
		if amountUGX >= f.RangeLow && (f.RangeHigh == 0 || amountUGX <= f.RangeHigh) {
			return &f
		}
	}
	return nil
}

type CropCalendarEntry struct {
	Crop         string
	Region       string // broad Uganda region: e.g. "Eastern", "Northern", "Central", "Western"
	PlantingWindow string
	HarvestWindow  string
	Notes          string
}

// CropCalendar is a small illustrative starting set for the Agriculture
// Assistant capability. Real agronomic timing varies by district and by
// season (Uganda has two rainy seasons in most regions) — this is a
// starting scaffold to seed real, locally-sourced data into.
var CropCalendar = []CropCalendarEntry{
	{Crop: "maize", Region: "Eastern", PlantingWindow: "March–April (first rains)", HarvestWindow: "July–August", Notes: "Second season planting also possible Aug–Sept in some districts."},
	{Crop: "beans", Region: "Eastern", PlantingWindow: "March–April", HarvestWindow: "June–July", Notes: "Fast-maturing, often intercropped with maize."},
	{Crop: "cassava", Region: "Northern", PlantingWindow: "April–May", HarvestWindow: "9–12 months after planting", Notes: "Drought-tolerant; flexible harvest window."},
	{Crop: "groundnuts", Region: "Eastern", PlantingWindow: "April–May", HarvestWindow: "August–September", Notes: ""},
	{Crop: "coffee (robusta)", Region: "Central", PlantingWindow: "March–May or Sept–Nov", HarvestWindow: "Year-round, peak Oct–Feb", Notes: "Perennial crop; planting window applies to new seedlings."},
}

// CropsFor returns calendar entries for a crop name (case-insensitive
// substring match), across all regions.
func CropsFor(crop string) []CropCalendarEntry {
	crop = strings.ToLower(strings.TrimSpace(crop))
	var out []CropCalendarEntry
	for _, entry := range CropCalendar {
		if strings.Contains(strings.ToLower(entry.Crop), crop) {
			out = append(out, entry)
		}
	}
	return out
}
