# SABA

**SABA — Smart Automation for Business in Africa** is a modular intelligence and automation platform with a Go core, browser dashboard, Flutter client, business-tool registry, and optional OpenAI Agents orchestration service.

## Repository structure

```text
Saba-main/
├── cmd/saba/             # Go HTTP service entrypoint
├── internal/
│   ├── agent/             # Tool registry, business tools, memory and scraper
│   ├── capabilities/      # Specialist capability detection and guidance
│   ├── database/          # SQLite-backed inventory and order storage
│   ├── gateway/           # Agent routing boundary
│   ├── intelligence/      # Research, analysis and reasoning pipeline
│   └── modes/             # Assistant / Teacher / Coach / Project Manager
├── mobile/                # Flutter Android/iOS client
├── web/                   # Embedded browser dashboard
├── openai_agents/         # Optional private OpenAI Agents service
└── docs/                  # Architecture and integration documentation
```

## Go service

Requirements: Go 1.23+.

```bash
go test ./...
go run ./cmd/saba
```

Default address: `http://127.0.0.1:8080`.

Endpoints:

- `GET /health` — health check
- `GET /tools` — discover registered business tools
- `POST /analyze` — research and analyze a question
- `POST /agent` — mode-aware agent gateway boundary
- `GET /dashboard/` — embedded browser dashboard

Example:

```bash
curl -X POST http://127.0.0.1:8080/analyze \
  -H 'Content-Type: application/json' \
  -d '{"question":"What opportunities could AI create for small businesses in Uganda?"}'
```

## Flutter client

```bash
cd mobile
flutter pub get
flutter run
```

For an Android emulator, the default API endpoint is `http://10.0.2.2:8080`. For a physical phone or another host, configure the endpoint at build time:

```bash
flutter run --dart-define=SABA_API_URL=http://YOUR-LAN-IP:8080
```

## Optional OpenAI Agents service

The Python service under `openai_agents/` is deliberately isolated from the Go core. It provides research, analysis, reasoning, business and coding-coordination agents using the OpenAI Agents SDK.

```bash
cd openai_agents
cp .env.example .env
# set OPENAI_API_KEY in .env
./test.sh
./run.sh
```

Keep this service private unless authentication and network controls are added at the deployment boundary.

## Security baseline

- Go binds to localhost by default.
- JSON request bodies are size-limited.
- The web scraper rejects localhost/private/link-local targets and unsafe redirects.
- API keys are environment-only and `.env.example` remains trackable.
- Payment support is currently a provider-validation boundary, not a live payment processor.

See `docs/ARCHITECTURE.md`, `docs/SABA_CAPABILITIES.md`, and `docs/UNIFIED_TOOLKIT.md` for more detail.

## Application mode

SABA can be used as an installable web application from `/dashboard/` (PWA), or as the native Flutter mobile client in `mobile/`. Start the server with `./RUN-SABA.sh`. See `APPLICATION.md` for deployment and Android build instructions.
